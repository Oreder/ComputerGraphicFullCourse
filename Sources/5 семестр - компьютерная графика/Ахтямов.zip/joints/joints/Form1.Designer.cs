﻿namespace joints
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pbCanvas = new System.Windows.Forms.PictureBox();
            this.light_x = new System.Windows.Forms.TextBox();
            this.light_y = new System.Windows.Forms.TextBox();
            this.light_z = new System.Windows.Forms.TextBox();
            this.BtnLightSource = new System.Windows.Forms.Button();
            this.intense = new System.Windows.Forms.TextBox();
            this.lblLightY = new System.Windows.Forms.Label();
            this.lblLightX = new System.Windows.Forms.Label();
            this.lblLightIntensity = new System.Windows.Forms.Label();
            this.lblLightZ = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabModeling = new System.Windows.Forms.TabPage();
            this.edtMousePosition = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();
            this.textBoxColor = new System.Windows.Forms.TextBox();
            this.btnColor = new System.Windows.Forms.Button();
            this.btnDelDown = new System.Windows.Forms.Button();
            this.btnDelUp = new System.Windows.Forms.Button();
            this.groupJoint = new System.Windows.Forms.GroupBox();
            this.btnJointDown = new System.Windows.Forms.Button();
            this.btnJointUp = new System.Windows.Forms.Button();
            this.btnAddItemDown = new System.Windows.Forms.Button();
            this.btnAddItemUp = new System.Windows.Forms.Button();
            this.ObjectsBox = new System.Windows.Forms.ComboBox();
            this.tabView = new System.Windows.Forms.TabPage();
            this.groupBoxRotate = new System.Windows.Forms.GroupBox();
            this.radioButtonAll = new System.Windows.Forms.RadioButton();
            this.radioButtonBottom = new System.Windows.Forms.RadioButton();
            this.radioButtonTop = new System.Windows.Forms.RadioButton();
            this.groupBoxScale = new System.Windows.Forms.GroupBox();
            this.btnScaleMinus = new System.Windows.Forms.Button();
            this.btnScalePlus = new System.Windows.Forms.Button();
            this.groupBoxMoveCamera = new System.Windows.Forms.GroupBox();
            this.btnMoveCamLeft = new System.Windows.Forms.Button();
            this.btnMoveCamDown = new System.Windows.Forms.Button();
            this.btnMoveCamRight = new System.Windows.Forms.Button();
            this.btnMoveCamUp = new System.Windows.Forms.Button();
            this.groupBoxCamera = new System.Windows.Forms.GroupBox();
            this.CameraUp = new System.Windows.Forms.Button();
            this.CameraDown = new System.Windows.Forms.Button();
            this.CameraLeft = new System.Windows.Forms.Button();
            this.CameraRight = new System.Windows.Forms.Button();
            this.listBoxJoints = new System.Windows.Forms.ListBox();
            this.ObjectColorDialog = new System.Windows.Forms.ColorDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.сценаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.параметрыОбъектовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.параметрыРазбиенияНаТреугольникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.параметрыУгловПоворотаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вкладкаМоделированиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вкладкаОбзорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клавишиУправленияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pbCanvas)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabModeling.SuspendLayout();
            this.groupJoint.SuspendLayout();
            this.tabView.SuspendLayout();
            this.groupBoxRotate.SuspendLayout();
            this.groupBoxScale.SuspendLayout();
            this.groupBoxMoveCamera.SuspendLayout();
            this.groupBoxCamera.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbCanvas
            // 
            this.pbCanvas.BackColor = System.Drawing.SystemColors.Window;
            this.pbCanvas.Location = new System.Drawing.Point(3, 34);
            this.pbCanvas.Name = "pbCanvas";
            this.pbCanvas.Size = new System.Drawing.Size(681, 517);
            this.pbCanvas.TabIndex = 0;
            this.pbCanvas.TabStop = false;
            this.pbCanvas.MouseLeave += new System.EventHandler(this.pbCanvas_MouseLeave);
            this.pbCanvas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbCanvas_MouseMove);
            // 
            // light_x
            // 
            this.light_x.Location = new System.Drawing.Point(25, 34);
            this.light_x.Name = "light_x";
            this.light_x.Size = new System.Drawing.Size(47, 20);
            this.light_x.TabIndex = 0;
            this.light_x.Text = "0";
            this.light_x.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // light_y
            // 
            this.light_y.Location = new System.Drawing.Point(89, 34);
            this.light_y.Name = "light_y";
            this.light_y.Size = new System.Drawing.Size(47, 20);
            this.light_y.TabIndex = 1;
            this.light_y.Text = "0";
            this.light_y.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // light_z
            // 
            this.light_z.Location = new System.Drawing.Point(153, 34);
            this.light_z.Name = "light_z";
            this.light_z.Size = new System.Drawing.Size(47, 20);
            this.light_z.TabIndex = 2;
            this.light_z.Text = "0";
            this.light_z.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // BtnLightSource
            // 
            this.BtnLightSource.Location = new System.Drawing.Point(71, 91);
            this.BtnLightSource.Name = "BtnLightSource";
            this.BtnLightSource.Size = new System.Drawing.Size(96, 32);
            this.BtnLightSource.TabIndex = 4;
            this.BtnLightSource.Text = "Установить";
            this.BtnLightSource.UseVisualStyleBackColor = true;
            this.BtnLightSource.Click += new System.EventHandler(this.BtnLightSource_Click);
            this.BtnLightSource.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // intense
            // 
            this.intense.Location = new System.Drawing.Point(153, 65);
            this.intense.Name = "intense";
            this.intense.Size = new System.Drawing.Size(47, 20);
            this.intense.TabIndex = 3;
            this.intense.Text = "0";
            this.intense.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // lblLightY
            // 
            this.lblLightY.AutoSize = true;
            this.lblLightY.Location = new System.Drawing.Point(105, 18);
            this.lblLightY.Name = "lblLightY";
            this.lblLightY.Size = new System.Drawing.Size(12, 13);
            this.lblLightY.TabIndex = 4;
            this.lblLightY.Text = "y";
            // 
            // lblLightX
            // 
            this.lblLightX.AutoSize = true;
            this.lblLightX.Location = new System.Drawing.Point(41, 18);
            this.lblLightX.Name = "lblLightX";
            this.lblLightX.Size = new System.Drawing.Size(12, 13);
            this.lblLightX.TabIndex = 0;
            this.lblLightX.Text = "x";
            // 
            // lblLightIntensity
            // 
            this.lblLightIntensity.AutoSize = true;
            this.lblLightIntensity.Location = new System.Drawing.Point(31, 67);
            this.lblLightIntensity.Name = "lblLightIntensity";
            this.lblLightIntensity.Size = new System.Drawing.Size(110, 13);
            this.lblLightIntensity.TabIndex = 7;
            this.lblLightIntensity.Text = "интенсивность [0; 1]";
            // 
            // lblLightZ
            // 
            this.lblLightZ.AutoSize = true;
            this.lblLightZ.Location = new System.Drawing.Point(166, 18);
            this.lblLightZ.Name = "lblLightZ";
            this.lblLightZ.Size = new System.Drawing.Size(12, 13);
            this.lblLightZ.TabIndex = 2;
            this.lblLightZ.Text = "z";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.light_y);
            this.groupBox1.Controls.Add(this.lblLightIntensity);
            this.groupBox1.Controls.Add(this.BtnLightSource);
            this.groupBox1.Controls.Add(this.light_x);
            this.groupBox1.Controls.Add(this.intense);
            this.groupBox1.Controls.Add(this.lblLightX);
            this.groupBox1.Controls.Add(this.light_z);
            this.groupBox1.Controls.Add(this.lblLightZ);
            this.groupBox1.Controls.Add(this.lblLightY);
            this.groupBox1.Location = new System.Drawing.Point(14, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(226, 133);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Источник освещения";
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabModeling);
            this.tabControl.Controls.Add(this.tabView);
            this.tabControl.Location = new System.Drawing.Point(690, 27);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(254, 524);
            this.tabControl.TabIndex = 9;
            this.tabControl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // tabModeling
            // 
            this.tabModeling.BackColor = System.Drawing.Color.Silver;
            this.tabModeling.Controls.Add(this.edtMousePosition);
            this.tabModeling.Controls.Add(this.label1);
            this.tabModeling.Controls.Add(this.lblColor);
            this.tabModeling.Controls.Add(this.textBoxColor);
            this.tabModeling.Controls.Add(this.btnColor);
            this.tabModeling.Controls.Add(this.btnDelDown);
            this.tabModeling.Controls.Add(this.groupBox1);
            this.tabModeling.Controls.Add(this.btnDelUp);
            this.tabModeling.Controls.Add(this.groupJoint);
            this.tabModeling.Controls.Add(this.btnAddItemDown);
            this.tabModeling.Controls.Add(this.btnAddItemUp);
            this.tabModeling.Controls.Add(this.ObjectsBox);
            this.tabModeling.Location = new System.Drawing.Point(4, 22);
            this.tabModeling.Name = "tabModeling";
            this.tabModeling.Padding = new System.Windows.Forms.Padding(3);
            this.tabModeling.Size = new System.Drawing.Size(246, 498);
            this.tabModeling.TabIndex = 0;
            this.tabModeling.Text = "Моделирование";
            // 
            // edtMousePosition
            // 
            this.edtMousePosition.Location = new System.Drawing.Point(140, 445);
            this.edtMousePosition.Name = "edtMousePosition";
            this.edtMousePosition.Size = new System.Drawing.Size(100, 20);
            this.edtMousePosition.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 449);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Позиция курсора:";
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new System.Drawing.Point(11, 182);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(38, 13);
            this.lblColor.TabIndex = 11;
            this.lblColor.Text = "Цвет: ";
            // 
            // textBoxColor
            // 
            this.textBoxColor.Location = new System.Drawing.Point(48, 179);
            this.textBoxColor.Name = "textBoxColor";
            this.textBoxColor.ReadOnly = true;
            this.textBoxColor.Size = new System.Drawing.Size(70, 20);
            this.textBoxColor.TabIndex = 10;
            this.textBoxColor.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(132, 172);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(108, 32);
            this.btnColor.TabIndex = 9;
            this.btnColor.Text = "Выбрать цвет";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            this.btnColor.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnDelDown
            // 
            this.btnDelDown.Location = new System.Drawing.Point(131, 258);
            this.btnDelDown.Name = "btnDelDown";
            this.btnDelDown.Size = new System.Drawing.Size(111, 39);
            this.btnDelDown.TabIndex = 4;
            this.btnDelDown.Text = "Удалить нижний элемент";
            this.btnDelDown.UseVisualStyleBackColor = true;
            this.btnDelDown.Click += new System.EventHandler(this.btnDelDown_Click);
            this.btnDelDown.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnDelUp
            // 
            this.btnDelUp.Location = new System.Drawing.Point(131, 214);
            this.btnDelUp.Name = "btnDelUp";
            this.btnDelUp.Size = new System.Drawing.Size(111, 39);
            this.btnDelUp.TabIndex = 4;
            this.btnDelUp.Text = "Удалить верхний элемент";
            this.btnDelUp.UseVisualStyleBackColor = true;
            this.btnDelUp.Click += new System.EventHandler(this.btnDelUp_Click);
            this.btnDelUp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // groupJoint
            // 
            this.groupJoint.Controls.Add(this.btnJointDown);
            this.groupJoint.Controls.Add(this.btnJointUp);
            this.groupJoint.Location = new System.Drawing.Point(42, 312);
            this.groupJoint.Name = "groupJoint";
            this.groupJoint.Size = new System.Drawing.Size(165, 112);
            this.groupJoint.TabIndex = 3;
            this.groupJoint.TabStop = false;
            this.groupJoint.Text = "Добавить сочленение";
            // 
            // btnJointDown
            // 
            this.btnJointDown.Location = new System.Drawing.Point(26, 62);
            this.btnJointDown.Name = "btnJointDown";
            this.btnJointDown.Size = new System.Drawing.Size(110, 37);
            this.btnJointDown.TabIndex = 0;
            this.btnJointDown.Text = "Снизу";
            this.btnJointDown.UseVisualStyleBackColor = true;
            this.btnJointDown.Click += new System.EventHandler(this.btnJointDown_Click);
            this.btnJointDown.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnJointUp
            // 
            this.btnJointUp.Location = new System.Drawing.Point(26, 21);
            this.btnJointUp.Name = "btnJointUp";
            this.btnJointUp.Size = new System.Drawing.Size(110, 35);
            this.btnJointUp.TabIndex = 0;
            this.btnJointUp.Text = "Сверху";
            this.btnJointUp.UseVisualStyleBackColor = true;
            this.btnJointUp.Click += new System.EventHandler(this.btnJointUp_Click);
            this.btnJointUp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnAddItemDown
            // 
            this.btnAddItemDown.Location = new System.Drawing.Point(14, 258);
            this.btnAddItemDown.Name = "btnAddItemDown";
            this.btnAddItemDown.Size = new System.Drawing.Size(111, 39);
            this.btnAddItemDown.TabIndex = 2;
            this.btnAddItemDown.Text = "Добавить снизу";
            this.btnAddItemDown.UseVisualStyleBackColor = true;
            this.btnAddItemDown.Click += new System.EventHandler(this.btnAddItemDown_Click);
            this.btnAddItemDown.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnAddItemUp
            // 
            this.btnAddItemUp.Location = new System.Drawing.Point(14, 214);
            this.btnAddItemUp.Name = "btnAddItemUp";
            this.btnAddItemUp.Size = new System.Drawing.Size(111, 39);
            this.btnAddItemUp.TabIndex = 1;
            this.btnAddItemUp.Text = "Добавить сверху";
            this.btnAddItemUp.UseVisualStyleBackColor = true;
            this.btnAddItemUp.Click += new System.EventHandler(this.btnAddItemUp_Click);
            this.btnAddItemUp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // ObjectsBox
            // 
            this.ObjectsBox.DisplayMember = "0";
            this.ObjectsBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ObjectsBox.FormattingEnabled = true;
            this.ObjectsBox.Items.AddRange(new object[] {
            "Цилиндр",
            "Усеченный конус",
            "Конус"});
            this.ObjectsBox.Location = new System.Drawing.Point(14, 145);
            this.ObjectsBox.Name = "ObjectsBox";
            this.ObjectsBox.Size = new System.Drawing.Size(226, 21);
            this.ObjectsBox.TabIndex = 0;
            this.ObjectsBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // tabView
            // 
            this.tabView.BackColor = System.Drawing.Color.Silver;
            this.tabView.Controls.Add(this.groupBoxRotate);
            this.tabView.Controls.Add(this.groupBoxScale);
            this.tabView.Controls.Add(this.groupBoxMoveCamera);
            this.tabView.Controls.Add(this.groupBoxCamera);
            this.tabView.Controls.Add(this.listBoxJoints);
            this.tabView.Location = new System.Drawing.Point(4, 22);
            this.tabView.Name = "tabView";
            this.tabView.Padding = new System.Windows.Forms.Padding(3);
            this.tabView.Size = new System.Drawing.Size(246, 498);
            this.tabView.TabIndex = 1;
            this.tabView.Text = "Обзор";
            this.tabView.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabView_MouseClick);
            // 
            // groupBoxRotate
            // 
            this.groupBoxRotate.Controls.Add(this.radioButtonAll);
            this.groupBoxRotate.Controls.Add(this.radioButtonBottom);
            this.groupBoxRotate.Controls.Add(this.radioButtonTop);
            this.groupBoxRotate.Location = new System.Drawing.Point(16, 121);
            this.groupBoxRotate.Name = "groupBoxRotate";
            this.groupBoxRotate.Size = new System.Drawing.Size(200, 51);
            this.groupBoxRotate.TabIndex = 14;
            this.groupBoxRotate.TabStop = false;
            this.groupBoxRotate.Text = "Вращение объектов";
            // 
            // radioButtonAll
            // 
            this.radioButtonAll.AutoSize = true;
            this.radioButtonAll.Location = new System.Drawing.Point(143, 22);
            this.radioButtonAll.Name = "radioButtonAll";
            this.radioButtonAll.Size = new System.Drawing.Size(44, 17);
            this.radioButtonAll.TabIndex = 2;
            this.radioButtonAll.TabStop = true;
            this.radioButtonAll.Text = "Все";
            this.radioButtonAll.UseVisualStyleBackColor = true;
            // 
            // radioButtonBottom
            // 
            this.radioButtonBottom.AutoSize = true;
            this.radioButtonBottom.Location = new System.Drawing.Point(75, 22);
            this.radioButtonBottom.Name = "radioButtonBottom";
            this.radioButtonBottom.Size = new System.Drawing.Size(65, 17);
            this.radioButtonBottom.TabIndex = 1;
            this.radioButtonBottom.Text = "Нижние";
            this.radioButtonBottom.UseVisualStyleBackColor = true;
            // 
            // radioButtonTop
            // 
            this.radioButtonTop.AutoSize = true;
            this.radioButtonTop.Checked = true;
            this.radioButtonTop.Location = new System.Drawing.Point(6, 22);
            this.radioButtonTop.Name = "radioButtonTop";
            this.radioButtonTop.Size = new System.Drawing.Size(67, 17);
            this.radioButtonTop.TabIndex = 0;
            this.radioButtonTop.TabStop = true;
            this.radioButtonTop.Text = "Верхние";
            this.radioButtonTop.UseVisualStyleBackColor = true;
            // 
            // groupBoxScale
            // 
            this.groupBoxScale.Controls.Add(this.btnScaleMinus);
            this.groupBoxScale.Controls.Add(this.btnScalePlus);
            this.groupBoxScale.Location = new System.Drawing.Point(16, 175);
            this.groupBoxScale.Name = "groupBoxScale";
            this.groupBoxScale.Size = new System.Drawing.Size(200, 54);
            this.groupBoxScale.TabIndex = 13;
            this.groupBoxScale.TabStop = false;
            this.groupBoxScale.Text = "Масштаб";
            // 
            // btnScaleMinus
            // 
            this.btnScaleMinus.Location = new System.Drawing.Point(127, 20);
            this.btnScaleMinus.Name = "btnScaleMinus";
            this.btnScaleMinus.Size = new System.Drawing.Size(64, 23);
            this.btnScaleMinus.TabIndex = 1;
            this.btnScaleMinus.Text = "-";
            this.btnScaleMinus.UseVisualStyleBackColor = true;
            this.btnScaleMinus.Click += new System.EventHandler(this.btnScaleMinus_Click);
            this.btnScaleMinus.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnScalePlus
            // 
            this.btnScalePlus.Location = new System.Drawing.Point(12, 20);
            this.btnScalePlus.Name = "btnScalePlus";
            this.btnScalePlus.Size = new System.Drawing.Size(64, 23);
            this.btnScalePlus.TabIndex = 0;
            this.btnScalePlus.Text = "+";
            this.btnScalePlus.UseVisualStyleBackColor = true;
            this.btnScalePlus.Click += new System.EventHandler(this.btnScalePlus_Click);
            this.btnScalePlus.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // groupBoxMoveCamera
            // 
            this.groupBoxMoveCamera.Controls.Add(this.btnMoveCamLeft);
            this.groupBoxMoveCamera.Controls.Add(this.btnMoveCamDown);
            this.groupBoxMoveCamera.Controls.Add(this.btnMoveCamRight);
            this.groupBoxMoveCamera.Controls.Add(this.btnMoveCamUp);
            this.groupBoxMoveCamera.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxMoveCamera.Location = new System.Drawing.Point(16, 244);
            this.groupBoxMoveCamera.Name = "groupBoxMoveCamera";
            this.groupBoxMoveCamera.Size = new System.Drawing.Size(200, 120);
            this.groupBoxMoveCamera.TabIndex = 12;
            this.groupBoxMoveCamera.TabStop = false;
            this.groupBoxMoveCamera.Text = "Сдвинуть камеру";
            // 
            // btnMoveCamLeft
            // 
            this.btnMoveCamLeft.Location = new System.Drawing.Point(12, 52);
            this.btnMoveCamLeft.Name = "btnMoveCamLeft";
            this.btnMoveCamLeft.Size = new System.Drawing.Size(64, 31);
            this.btnMoveCamLeft.TabIndex = 0;
            this.btnMoveCamLeft.Text = "Влево";
            this.btnMoveCamLeft.UseVisualStyleBackColor = true;
            this.btnMoveCamLeft.Click += new System.EventHandler(this.btnMoveCamLeft_Click);
            this.btnMoveCamLeft.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnMoveCamDown
            // 
            this.btnMoveCamDown.Location = new System.Drawing.Point(67, 84);
            this.btnMoveCamDown.Name = "btnMoveCamDown";
            this.btnMoveCamDown.Size = new System.Drawing.Size(64, 31);
            this.btnMoveCamDown.TabIndex = 0;
            this.btnMoveCamDown.Text = "Вниз";
            this.btnMoveCamDown.UseVisualStyleBackColor = true;
            this.btnMoveCamDown.Click += new System.EventHandler(this.btnMoveCamDown_Click);
            this.btnMoveCamDown.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnMoveCamRight
            // 
            this.btnMoveCamRight.Location = new System.Drawing.Point(124, 52);
            this.btnMoveCamRight.Name = "btnMoveCamRight";
            this.btnMoveCamRight.Size = new System.Drawing.Size(64, 31);
            this.btnMoveCamRight.TabIndex = 0;
            this.btnMoveCamRight.Text = "Вправо";
            this.btnMoveCamRight.UseVisualStyleBackColor = true;
            this.btnMoveCamRight.Click += new System.EventHandler(this.btnMoveCamRight_Click);
            this.btnMoveCamRight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // btnMoveCamUp
            // 
            this.btnMoveCamUp.Location = new System.Drawing.Point(67, 19);
            this.btnMoveCamUp.Name = "btnMoveCamUp";
            this.btnMoveCamUp.Size = new System.Drawing.Size(64, 31);
            this.btnMoveCamUp.TabIndex = 0;
            this.btnMoveCamUp.Text = "Вверх";
            this.btnMoveCamUp.UseVisualStyleBackColor = true;
            this.btnMoveCamUp.Click += new System.EventHandler(this.btnMoveCamUp_Click);
            this.btnMoveCamUp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // groupBoxCamera
            // 
            this.groupBoxCamera.Controls.Add(this.CameraUp);
            this.groupBoxCamera.Controls.Add(this.CameraDown);
            this.groupBoxCamera.Controls.Add(this.CameraLeft);
            this.groupBoxCamera.Controls.Add(this.CameraRight);
            this.groupBoxCamera.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBoxCamera.Location = new System.Drawing.Point(16, 370);
            this.groupBoxCamera.Name = "groupBoxCamera";
            this.groupBoxCamera.Size = new System.Drawing.Size(200, 123);
            this.groupBoxCamera.TabIndex = 12;
            this.groupBoxCamera.TabStop = false;
            this.groupBoxCamera.Text = "Повернуть камеру";
            // 
            // CameraUp
            // 
            this.CameraUp.Location = new System.Drawing.Point(67, 22);
            this.CameraUp.Name = "CameraUp";
            this.CameraUp.Size = new System.Drawing.Size(64, 31);
            this.CameraUp.TabIndex = 1;
            this.CameraUp.Text = "Вверх";
            this.CameraUp.UseVisualStyleBackColor = true;
            this.CameraUp.Click += new System.EventHandler(this.CameraUp_Click);
            this.CameraUp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // CameraDown
            // 
            this.CameraDown.Location = new System.Drawing.Point(67, 85);
            this.CameraDown.Name = "CameraDown";
            this.CameraDown.Size = new System.Drawing.Size(64, 31);
            this.CameraDown.TabIndex = 11;
            this.CameraDown.Text = "Вниз";
            this.CameraDown.UseVisualStyleBackColor = true;
            this.CameraDown.Click += new System.EventHandler(this.CameraDown_Click);
            this.CameraDown.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // CameraLeft
            // 
            this.CameraLeft.Location = new System.Drawing.Point(12, 54);
            this.CameraLeft.Name = "CameraLeft";
            this.CameraLeft.Size = new System.Drawing.Size(64, 31);
            this.CameraLeft.TabIndex = 1;
            this.CameraLeft.Text = "Влево";
            this.CameraLeft.UseVisualStyleBackColor = true;
            this.CameraLeft.Click += new System.EventHandler(this.CameraLeft_Click);
            this.CameraLeft.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // CameraRight
            // 
            this.CameraRight.Location = new System.Drawing.Point(123, 53);
            this.CameraRight.Name = "CameraRight";
            this.CameraRight.Size = new System.Drawing.Size(64, 31);
            this.CameraRight.TabIndex = 1;
            this.CameraRight.Text = "Вправо";
            this.CameraRight.UseVisualStyleBackColor = true;
            this.CameraRight.Click += new System.EventHandler(this.CameraRight_Click);
            this.CameraRight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            // 
            // listBoxJoints
            // 
            this.listBoxJoints.FormattingEnabled = true;
            this.listBoxJoints.Location = new System.Drawing.Point(7, 7);
            this.listBoxJoints.Name = "listBoxJoints";
            this.listBoxJoints.Size = new System.Drawing.Size(233, 108);
            this.listBoxJoints.TabIndex = 0;
            this.listBoxJoints.SelectedIndexChanged += new System.EventHandler(this.listBoxJoints_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сценаToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(956, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // сценаToolStripMenuItem
            // 
            this.сценаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.очиститьToolStripMenuItem,
            this.параметрыОбъектовToolStripMenuItem,
            this.параметрыРазбиенияНаТреугольникиToolStripMenuItem,
            this.параметрыУгловПоворотаToolStripMenuItem});
            this.сценаToolStripMenuItem.Name = "сценаToolStripMenuItem";
            this.сценаToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.сценаToolStripMenuItem.Text = "Сцена";
            // 
            // очиститьToolStripMenuItem
            // 
            this.очиститьToolStripMenuItem.Name = "очиститьToolStripMenuItem";
            this.очиститьToolStripMenuItem.Size = new System.Drawing.Size(294, 22);
            this.очиститьToolStripMenuItem.Text = "Очистить";
            this.очиститьToolStripMenuItem.Click += new System.EventHandler(this.очиститьToolStripMenuItem_Click);
            // 
            // параметрыОбъектовToolStripMenuItem
            // 
            this.параметрыОбъектовToolStripMenuItem.Name = "параметрыОбъектовToolStripMenuItem";
            this.параметрыОбъектовToolStripMenuItem.Size = new System.Drawing.Size(294, 22);
            this.параметрыОбъектовToolStripMenuItem.Text = "Параметры объектов";
            this.параметрыОбъектовToolStripMenuItem.Click += new System.EventHandler(this.параметрыОбъектовToolStripMenuItem_Click);
            // 
            // параметрыРазбиенияНаТреугольникиToolStripMenuItem
            // 
            this.параметрыРазбиенияНаТреугольникиToolStripMenuItem.Name = "параметрыРазбиенияНаТреугольникиToolStripMenuItem";
            this.параметрыРазбиенияНаТреугольникиToolStripMenuItem.Size = new System.Drawing.Size(294, 22);
            this.параметрыРазбиенияНаТреугольникиToolStripMenuItem.Text = "Параметры разбиения на треугольники";
            this.параметрыРазбиенияНаТреугольникиToolStripMenuItem.Click += new System.EventHandler(this.параметрыРазбиенияНаТреугольникиToolStripMenuItem_Click);
            // 
            // параметрыУгловПоворотаToolStripMenuItem
            // 
            this.параметрыУгловПоворотаToolStripMenuItem.Name = "параметрыУгловПоворотаToolStripMenuItem";
            this.параметрыУгловПоворотаToolStripMenuItem.Size = new System.Drawing.Size(294, 22);
            this.параметрыУгловПоворотаToolStripMenuItem.Text = "Параметры углов поворота и сдвигов";
            this.параметрыУгловПоворотаToolStripMenuItem.Click += new System.EventHandler(this.параметрыУгловПоворотаToolStripMenuItem_Click);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вкладкаМоделированиеToolStripMenuItem,
            this.вкладкаОбзорToolStripMenuItem,
            this.клавишиУправленияToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // вкладкаМоделированиеToolStripMenuItem
            // 
            this.вкладкаМоделированиеToolStripMenuItem.Name = "вкладкаМоделированиеToolStripMenuItem";
            this.вкладкаМоделированиеToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.вкладкаМоделированиеToolStripMenuItem.Text = "Вкладка \"Моделирование\"";
            this.вкладкаМоделированиеToolStripMenuItem.Click += new System.EventHandler(this.вкладкаМоделированиеToolStripMenuItem_Click);
            // 
            // вкладкаОбзорToolStripMenuItem
            // 
            this.вкладкаОбзорToolStripMenuItem.Name = "вкладкаОбзорToolStripMenuItem";
            this.вкладкаОбзорToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.вкладкаОбзорToolStripMenuItem.Text = "Вкладка \"Обзор\"";
            this.вкладкаОбзорToolStripMenuItem.Click += new System.EventHandler(this.вкладкаОбзорToolStripMenuItem_Click);
            // 
            // клавишиУправленияToolStripMenuItem
            // 
            this.клавишиУправленияToolStripMenuItem.Name = "клавишиУправленияToolStripMenuItem";
            this.клавишиУправленияToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.клавишиУправленияToolStripMenuItem.Text = "Клавиши управления";
            this.клавишиУправленияToolStripMenuItem.Click += new System.EventHandler(this.клавишиУправленияToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(956, 554);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.pbCanvas);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Моделирование сочлененных объектов";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pbCanvas)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.tabModeling.ResumeLayout(false);
            this.tabModeling.PerformLayout();
            this.groupJoint.ResumeLayout(false);
            this.tabView.ResumeLayout(false);
            this.groupBoxRotate.ResumeLayout(false);
            this.groupBoxRotate.PerformLayout();
            this.groupBoxScale.ResumeLayout(false);
            this.groupBoxMoveCamera.ResumeLayout(false);
            this.groupBoxCamera.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCanvas;
        private System.Windows.Forms.TextBox light_x;
        private System.Windows.Forms.TextBox light_y;
        private System.Windows.Forms.TextBox light_z;
        private System.Windows.Forms.Button BtnLightSource;
        private System.Windows.Forms.TextBox intense;
        private System.Windows.Forms.Label lblLightY;
        private System.Windows.Forms.Label lblLightX;
        private System.Windows.Forms.Label lblLightIntensity;
        private System.Windows.Forms.Label lblLightZ;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabModeling;
        private System.Windows.Forms.ComboBox ObjectsBox;
        private System.Windows.Forms.TabPage tabView;
        private System.Windows.Forms.Button btnAddItemDown;
        private System.Windows.Forms.Button btnAddItemUp;
        private System.Windows.Forms.GroupBox groupJoint;
        private System.Windows.Forms.Button btnJointDown;
        private System.Windows.Forms.Button btnJointUp;
        private System.Windows.Forms.Button btnDelDown;
        private System.Windows.Forms.Button btnDelUp;
        private System.Windows.Forms.ListBox listBoxJoints;
        private System.Windows.Forms.Button CameraDown;
        private System.Windows.Forms.Button CameraRight;
        private System.Windows.Forms.Button CameraLeft;
        private System.Windows.Forms.Button CameraUp;
        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.ColorDialog ObjectColorDialog;
        private System.Windows.Forms.TextBox textBoxColor;
        private System.Windows.Forms.Label lblColor;
        private System.Windows.Forms.GroupBox groupBoxCamera;
        private System.Windows.Forms.GroupBox groupBoxScale;
        private System.Windows.Forms.Button btnScaleMinus;
        private System.Windows.Forms.Button btnScalePlus;
        private System.Windows.Forms.GroupBox groupBoxMoveCamera;
        private System.Windows.Forms.Button btnMoveCamLeft;
        private System.Windows.Forms.Button btnMoveCamDown;
        private System.Windows.Forms.Button btnMoveCamRight;
        private System.Windows.Forms.Button btnMoveCamUp;
        private System.Windows.Forms.GroupBox groupBoxRotate;
        private System.Windows.Forms.RadioButton radioButtonBottom;
        private System.Windows.Forms.RadioButton radioButtonTop;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem сценаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem очиститьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem параметрыОбъектовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem параметрыРазбиенияНаТреугольникиToolStripMenuItem;
        private System.Windows.Forms.RadioButton radioButtonAll;
        private System.Windows.Forms.ToolStripMenuItem параметрыУгловПоворотаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вкладкаМоделированиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вкладкаОбзорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клавишиУправленияToolStripMenuItem;
        private System.Windows.Forms.TextBox edtMousePosition;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
    }
}

