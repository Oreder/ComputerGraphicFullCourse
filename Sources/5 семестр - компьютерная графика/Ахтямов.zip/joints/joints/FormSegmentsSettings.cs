﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace joints
{
    public partial class FormSegmentsSettings : Form
    {
        Form1 form;
        public FormSegmentsSettings(Form1 _form)
        {
            InitializeComponent();
            form = _form;
            edtJointHeight.Text = form.joint_height_segments.ToString();
            edtJointRound.Text = form.joint_round_segments.ToString();
            edtObjHeight.Text = form.height_segments.ToString();
            edtObjRound.Text = form.round_segments.ToString();
            btnFix.Enabled = false;
        }

        private void edtObjRound_TextChanged(object sender, EventArgs e)
        {
            btnFix.Enabled = true;
        }

        private void btnFix_Click(object sender, EventArgs e)
        {
            try
            {
                form.joint_height_segments = Convert.ToInt32(edtJointHeight.Text);
                form.joint_round_segments = Convert.ToInt32(edtJointRound.Text);
                form.height_segments = Convert.ToInt32(edtObjHeight.Text);
                form.round_segments = Convert.ToInt32(edtObjRound.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Проверьте корректность введенных данных. В поля могут быть введены только целые числа");
                return;
            }
            Close();
        }

        private void btnDefault_Click(object sender, EventArgs e)
        {
            edtJointHeight.Text = "16";
            edtJointRound.Text = "40";
            edtObjHeight.Text = "3";
            edtObjRound.Text = "40";
        }
    }
}
