﻿namespace joints
{
    partial class FormAngleSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.edtAngle = new System.Windows.Forms.TextBox();
            this.edtCameraAngle = new System.Windows.Forms.TextBox();
            this.btnFix = new System.Windows.Forms.Button();
            this.btnDefault = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.edtMotions = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Угол поворота объектов";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Угол поворота камеры";
            // 
            // edtAngle
            // 
            this.edtAngle.Location = new System.Drawing.Point(166, 19);
            this.edtAngle.Name = "edtAngle";
            this.edtAngle.Size = new System.Drawing.Size(51, 20);
            this.edtAngle.TabIndex = 1;
            this.edtAngle.TextChanged += new System.EventHandler(this.edtAngle_TextChanged);
            // 
            // edtCameraAngle
            // 
            this.edtCameraAngle.Location = new System.Drawing.Point(166, 58);
            this.edtCameraAngle.Name = "edtCameraAngle";
            this.edtCameraAngle.Size = new System.Drawing.Size(51, 20);
            this.edtCameraAngle.TabIndex = 1;
            this.edtCameraAngle.TextChanged += new System.EventHandler(this.edtAngle_TextChanged);
            // 
            // btnFix
            // 
            this.btnFix.Location = new System.Drawing.Point(124, 161);
            this.btnFix.Name = "btnFix";
            this.btnFix.Size = new System.Drawing.Size(93, 23);
            this.btnFix.TabIndex = 2;
            this.btnFix.Text = "Применить";
            this.btnFix.UseVisualStyleBackColor = true;
            this.btnFix.Click += new System.EventHandler(this.btnFix_Click);
            // 
            // btnDefault
            // 
            this.btnDefault.Location = new System.Drawing.Point(124, 130);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(93, 23);
            this.btnDefault.TabIndex = 2;
            this.btnDefault.Text = "По умолчанию";
            this.btnDefault.UseVisualStyleBackColor = true;
            this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Сдвиги камеры";
            // 
            // edtMotions
            // 
            this.edtMotions.Location = new System.Drawing.Point(166, 93);
            this.edtMotions.Name = "edtMotions";
            this.edtMotions.Size = new System.Drawing.Size(51, 20);
            this.edtMotions.TabIndex = 4;
            // 
            // FormAngleSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 193);
            this.Controls.Add(this.edtMotions);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.btnFix);
            this.Controls.Add(this.edtCameraAngle);
            this.Controls.Add(this.edtAngle);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormAngleSettings";
            this.Text = "Углы и сдвиги";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox edtAngle;
        private System.Windows.Forms.TextBox edtCameraAngle;
        private System.Windows.Forms.Button btnFix;
        private System.Windows.Forms.Button btnDefault;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox edtMotions;
    }
}