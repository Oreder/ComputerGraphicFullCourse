﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    class Cone : AbstractObject
    {
        TPoint Bottom;
        TPoint Top;
        private double BottomRadius;
        private double TopRadius;
        public Cone(TPoint _Bottom, double _BottomRadius, TPoint _Top, double _TopRadius)
        {
            Bottom = _Bottom;
            BottomRadius = _BottomRadius;
            Top = _Top;
            TopRadius = _TopRadius;
        }
        public void Triangulate(int round_segments, int height_segments, bool need_base = true)
        {
            double angle = Math.PI * 2 / round_segments;
            TPoint[] bottom_array = new TPoint[round_segments];
            TPoint[] top_array = new TPoint[round_segments];
            List<Triangle> bottom_triangles = new List<Triangle>();
            List<Triangle> top_triangles = new List<Triangle>();
            if (TopRadius == 0)
            {
                for (int i = 0; i < round_segments; i++)
                    bottom_array[i] = new TPoint(Bottom.getX() + BottomRadius * Math.Cos(angle * i), Bottom.getY(), Bottom.getZ() + BottomRadius * Math.Sin(angle * i), color);
                for (int i = 1; i < round_segments; i++)
                    bottom_triangles.Add(new Triangle(bottom_array[i], Bottom, bottom_array[i - 1]));
                bottom_triangles.Add(new Triangle(bottom_array[round_segments - 1], Bottom, bottom_array[0]));
                List<Triangle> side_triangles = new List<Triangle>();
                for (int i = 1; i < round_segments; i++)
                    side_triangles.Add(new Triangle(bottom_array[i - 1], Top, bottom_array[i]));
                side_triangles.Add(new Triangle(bottom_array[round_segments - 1], Top, bottom_array[0]));
                for (int i = 0; i < round_segments; i++)
                {
                    Vector normal_left;
                    if (i == 0)
                        normal_left = new Vector(side_triangles[round_segments - 1].GetNormal());
                    else
                        normal_left = new Vector(side_triangles[i - 1].GetNormal());
                    Vector normal = new Vector(side_triangles[i].GetNormal());
                    Vector normal_right = new Vector(side_triangles[(i + 1) % round_segments].GetNormal());

                    if (i < 3 || i > round_segments - 3)
                    {
                        if (normal_right.GetX() < 0)
                            normal_right.Negate();
                        if (normal_left.GetX() < 0)
                            normal_left.Negate();
                        if (normal.GetX() < 0)
                            normal.Negate();
                    }
                    else if (i <= round_segments / 2 + 3 && i >= round_segments / 2 - 3)
                    {
                        if (normal_right.GetX() > 0)
                            normal_right.Negate();
                        if (normal_left.GetX() > 0)
                            normal_left.Negate();
                        if (normal.GetX() > 0)
                            normal.Negate();
                    }

                    Vector tmp_left = new Vector(normal_left);
                    tmp_left.Sum(normal);
                    tmp_left.Normalize();
                    Vector tmp_right = new Vector(normal_right);
                    tmp_right.Sum(normal);
                    tmp_right.Normalize();

                    side_triangles[i].p1_end = side_triangles[i].p1.AddVector(tmp_left);
                    side_triangles[i].p2_end = side_triangles[i].p2.AddVector(side_triangles[i].GetNormal());
                    side_triangles[i].p3_end = side_triangles[i].p3.AddVector(tmp_right);
                }
                foreach(var item in bottom_triangles)
                {
                    item.p1_end = item.p1.AddVector(item.GetNormal());
                    item.p2_end = item.p2.AddVector(item.GetNormal());
                    item.p3_end = item.p3.AddVector(item.GetNormal());
                }
                foreach (var item in bottom_triangles)
                    container.Add(item);
                foreach (var item in side_triangles)
                    container.Add(item);
            }
            else if (BottomRadius == 0)
            {
                for (int i = 0; i < round_segments; i++)
                    top_array[i] = new TPoint(Top.getX() + TopRadius * Math.Cos(angle * i), Top.getY(), Top.getZ() + TopRadius * Math.Sin(angle * i), color);
                for (int i = 1; i < round_segments; i++)
                {
                    top_triangles.Add(new Triangle(top_array[i], Top, top_array[i - 1]));
                }
                top_triangles.Add(new Triangle(top_array[round_segments - 1], Top, top_array[0]));
                List<Triangle> side_triangles = new List<Triangle>();
                for (int i = 1; i < round_segments; i++)
                    side_triangles.Add(new Triangle(top_array[i - 1], Bottom, top_array[i]));
                side_triangles.Add(new Triangle(top_array[round_segments - 1], Bottom, top_array[0]));
                for (int i = 0; i < round_segments; i++)
                {
                    Vector normal_left;
                    if (i == 0)
                        normal_left = new Vector(side_triangles[round_segments - 1].GetNormal());
                    else
                        normal_left = new Vector(side_triangles[i - 1].GetNormal());
                    Vector normal = new Vector(side_triangles[i].GetNormal());
                    Vector normal_right = new Vector(side_triangles[(i + 1) % round_segments].GetNormal());

                    if (i < 3 || i > round_segments - 3)
                    {
                        if (normal_right.GetX() < 0)
                            normal_right.Negate();
                        if (normal_left.GetX() < 0)
                            normal_left.Negate();
                        if (normal.GetX() < 0)
                            normal.Negate();
                    }
                    else if (i <= round_segments / 2 + 3 && i >= round_segments / 2 - 3)
                    {
                        if (normal_right.GetX() > 0)
                            normal_right.Negate();
                        if (normal_left.GetX() > 0)
                            normal_left.Negate();
                        if (normal.GetX() > 0)
                            normal.Negate();
                    }

                    Vector tmp_left = new Vector(normal_left);
                    tmp_left.Sum(normal);
                    tmp_left.Normalize();
                    Vector tmp_right = new Vector(normal_right);
                    tmp_right.Sum(normal);
                    tmp_right.Normalize();

                    side_triangles[i].p1_end = side_triangles[i].p1.AddVector(tmp_left);
                    side_triangles[i].p2_end = side_triangles[i].p2.AddVector(side_triangles[i].GetNormal());
                    side_triangles[i].p3_end = side_triangles[i].p3.AddVector(tmp_right);
                }
                foreach (var item in top_triangles)
                {
                    item.p1_end = item.p1.AddVector(item.GetNormal());
                    item.p2_end = item.p2.AddVector(item.GetNormal());
                    item.p3_end = item.p3.AddVector(item.GetNormal());
                }
                foreach (var item in top_triangles)
                    container.Add(item);
                foreach (var item in side_triangles)
                    container.Add(item);
            }
            else
            {
                // расстановка точек по основаниям цилиндра
                for (int i = 0; i < round_segments; i++)
                    bottom_array[i] = new TPoint(Bottom.getX() + BottomRadius * Math.Cos(angle * i), Bottom.getY(), Bottom.getZ() + BottomRadius * Math.Sin(angle * i), color);
                for (int i = 1; i < round_segments; i++)
                    bottom_triangles.Add(new Triangle(bottom_array[i], Bottom, bottom_array[i - 1]));
                bottom_triangles.Add(new Triangle(bottom_array[round_segments - 1], Bottom, bottom_array[0]));

                for (int i = 0; i < round_segments; i++)
                    top_array[i] = new TPoint(Top.getX() + TopRadius * Math.Cos(angle * i), Top.getY(), Top.getZ() + TopRadius * Math.Sin(angle * i), color);
                for (int i = 1; i < round_segments; i++)
                {
                    top_triangles.Add(new Triangle(top_array[i], Top, top_array[i - 1]));
                }
                top_triangles.Add(new Triangle(top_array[round_segments - 1], Top, top_array[0]));

                // разбиение на треугольники по высоте
                double height = Bottom.getY() - Top.getY();
                double dx, dz;
                double dy = height / height_segments;
                TPoint[,] points = new TPoint[round_segments, height_segments + 1];
                for (int i = 0; i < round_segments; i++)
                {
                    points[i, 0] = bottom_array[i];
                    dx = (top_array[i].getX() - bottom_array[i].getX()) / height_segments;
                    dz = (top_array[i].getZ() - bottom_array[i].getZ()) / height_segments;
                    for (int j = 1; j <= height_segments; j++)
                    {
                        points[i, j] = new TPoint(points[i, j - 1].getX() + dx, points[i, j - 1].getY() - dy,
                            points[i, j - 1].getZ() + dz);
                    }
                }

                // Создание и заполнение матрицы квадратов
                Quadro[,] quadro_array = new Quadro[round_segments, height_segments];
                for (int i = 0; i < round_segments - 1; i++)
                {
                    for (int j = 0; j < height_segments; j++)
                    {
                        quadro_array[i, j] = new Quadro(points[i, j], points[i, j + 1],
                            points[i + 1, j + 1], points[i + 1, j]);
                    }
                }
                Triangle[,] side_triangles = new Triangle[round_segments, height_segments * 2];
                for (int i = 0; i < height_segments; i++)
                {
                    quadro_array[round_segments - 1, i] =
                        new Quadro(points[round_segments - 1, i], points[round_segments - 1, i + 1],
                        points[0, i + 1], points[0, i]);
                }
                for (int i = 0; i < round_segments; i++)
                {
                    for (int j = 0; j < height_segments; j++)
                    {
                        side_triangles[i, j * 2] = new Triangle(quadro_array[i, j].points[0], quadro_array[i, j].points[1],
                            quadro_array[i, j].points[3]);
                        side_triangles[i, j * 2 + 1] = new Triangle(quadro_array[i, j].points[1], quadro_array[i, j].points[2],
                            quadro_array[i, j].points[3]);
                    }
                }
                for (int i = 0; i < round_segments; i++)
                {
                    for (int j = 0; j < height_segments * 2; j += 2)
                    {
                        Vector normal_left;
                        if (i == 0)
                            normal_left = new Vector(side_triangles[round_segments - 1, j + 1].GetNormal());
                        else
                            normal_left = new Vector(side_triangles[i - 1, j + 1].GetNormal());
                        Vector normal = new Vector(side_triangles[i, j].GetNormal());
                        Vector normal_right = new Vector(side_triangles[(i + 1) % round_segments, j].GetNormal());

                        if (i < 3 || i > round_segments - 3)
                        {
                            if (normal_right.GetX() < 0)
                                normal_right.Negate();
                            if (normal_left.GetX() < 0)
                                normal_left.Negate();
                            if (normal.GetX() < 0)
                                normal.Negate();
                        }
                        else if (i <= round_segments / 2 + 3 && i >= round_segments / 2 - 3)
                        {
                            if (normal_right.GetX() > 0)
                                normal_right.Negate();
                            if (normal_left.GetX() > 0)
                                normal_left.Negate();
                            if (normal.GetX() > 0)
                                normal.Negate();
                        }

                        Vector tmp_left = new Vector(normal_left);
                        tmp_left.Sum(normal);
                        tmp_left.Normalize();
                        Vector tmp_right = new Vector(normal_right);
                        tmp_right.Sum(normal);
                        tmp_right.Normalize();

                        side_triangles[i, j].p1_end = side_triangles[i, j].p1.AddVector(tmp_left);
                        side_triangles[i, j].p2_end = side_triangles[i, j].p2.AddVector(tmp_left);
                        side_triangles[i, j].p3_end = side_triangles[i, j].p3.AddVector(tmp_right);
                        side_triangles[i, j + 1].p1_end = side_triangles[i, j + 1].p1.AddVector(tmp_left);
                        side_triangles[i, j + 1].p2_end = side_triangles[i, j + 1].p2.AddVector(tmp_right);
                        side_triangles[i, j + 1].p3_end = side_triangles[i, j + 1].p3.AddVector(tmp_right);
                    }
                }

                for (int i = 0; i < round_segments; i++)
                {
                    bottom_triangles[i].p1_end = bottom_triangles[i].p1.AddVector(bottom_triangles[i].GetNormal());
                    bottom_triangles[i].p3_end = bottom_triangles[i].p3.AddVector(bottom_triangles[i].GetNormal());
                    bottom_triangles[i].p2_end = bottom_triangles[i].p2.AddVector(bottom_triangles[i].GetNormal());
                }
                if (need_base)
                    foreach (var item in bottom_triangles)
                        container.Add(item);

                for (int i = 0; i < round_segments; i++)
                {
                    top_triangles[i].p1_end = top_triangles[i].p1.AddVector(top_triangles[i].GetNormal());
                    top_triangles[i].p3_end = top_triangles[i].p3.AddVector(top_triangles[i].GetNormal());
                    top_triangles[i].p2_end = top_triangles[i].p2.AddVector(top_triangles[i].GetNormal());
                }
                if (need_base)
                    foreach (var item in top_triangles)
                        container.Add(item);
                for (int i = 0; i < round_segments; i++)
                    for (int j = 0; j < 2 * height_segments; j++)
                        container.Add(side_triangles[i, j]);
            }
            foreach (var elem in container)
            {
                elem.setZbuffer(zbuffer);
                elem.setColor(color);
            }
        }
    }
}
