﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    public class TransformMatrix
    {
        public double [,] matrix = {
            {1, 0, 0, 0},
            {0, 1, 0, 0},
            {0, 0, 1, 0},
            {0, 0, 0, 1}
        };
                
        public void RotateX(double angle)
        {
            mult_matrix(RotationX(angle));
        }

        public void RotateY(double angle)
        {
            mult_matrix(RotationY(angle));
        }

        public void RotateZ(double angle)
        {
            mult_matrix(RotationZ(angle));
        }

        public void Scale(double kx, double ky, double kz)
        {
            mult_matrix(Scaling(kx, ky, kz));
        }
        
        public void Move(double dx, double dy, double dz)
        {
            mult_matrix(Motion(dx, dy, dz));
        }

        #region Matrix
        private double [,] RotationX(double angle)
        {
            double[,] buf = {
                {1, 0, 0, 0},
                {0, Math.Cos(angle), Math.Sin(angle), 0},
                {0, -Math.Sin(angle), Math.Cos(angle), 0},
                {0, 0, 0, 1}
            };
            return buf;
        }
        private double[,] RotationY(double angle)
        {
            double[,] buf = {
                {Math.Cos(angle), 0, -Math.Sin(angle), 0},
                {0, 1, 0, 0},
                {Math.Sin(angle), 0, Math.Cos(angle), 0},
                {0, 0, 0, 1}
            };
            return buf;
        }
        private double[,] RotationZ(double angle)
        {
            double[,] buf = {
                {Math.Cos(angle), Math.Sin(angle), 0, 0},
                {-Math.Sin(angle), Math.Cos(angle), 0, 0},
                {0, 0, 1, 0},
                {0, 0, 0, 1}
            };
            return buf;
        }

        private double[,] Motion(double dx, double dy, double dz)
        {
            double[,] buf = {
                {1, 0, 0, 0},
                {0, 1, 0, 0},
                {0, 0, 1, 0},
                {dx, dy, dz, 1}
            };
            return buf;
        }


        private double[,] Scaling(double kx, double ky, double kz)
        {         
            double[,] buf = {
                {kx, 0, 0, 0},
                {0, ky, 0, 0},
                {0, 0, kz, 0},
                {0, 0, 0, 1}
            };
            return buf;
        }
#endregion

        private void mult_matrix(double[,] transform)
        {
            double [,] buf = new double [4,4];
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                {
                    buf[i, j] = 0;
                    for (int k = 0; k < 4; k++)
                        buf[i, j] += matrix[i, k] * transform[k, j];
                }
            matrix = buf;
        }
    }
}
