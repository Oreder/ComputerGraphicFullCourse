﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;

namespace joints
{
    public class Bitmap_canvas
    {
        private int width;
        private int height;
        Bitmap bitmap;
        private BitmapData bmpData;
        private PixelFormat pxf = PixelFormat.Format32bppArgb;
        private Rectangle rect;
        public Bitmap_canvas(int w, int h)
        {
            width = w;
            height = h;
            bitmap = new Bitmap(width, height);
            rect = new Rectangle(0, 0, width, height);
        }

        public void setWidth(int _width)
        {
            width = _width;
        }

        public void setHeight(int _height)
        {
            height = _height;
        }

        public void setSizes(int _width, int _height)
        {
            setWidth(_width);
            setHeight(_height);
        }

        public int getWidth()
        {
            return width;
        }

        public int getHeight()
        {
            return height;
        }

        public Bitmap getBitmap()
        {
            return bitmap;
        }

        public unsafe Color getColor(int i, int j)
        {
            int* ptr = (int*)lockBits();
            int color = ptr[j * width + i];
            unlockBits();
            return Color.FromArgb(color);
        }
        
        public unsafe void DrawPoint(int x, int y, Color color)
        {
            int* ptr = (int*)lockBits();
            int _color = color.ToArgb();
            ptr[y * width + x] = _color;
            unlockBits();
        }
        public void unlockBits()
        {
            bitmap.UnlockBits(bmpData);
        }
        public unsafe int* lockBits()
        {
            bmpData = bitmap.LockBits(rect, ImageLockMode.ReadWrite, pxf);

            int* ptr = (int*)bmpData.Scan0.ToPointer();

            return ptr;
        }
        public void clear()
        {
            bitmap = new Bitmap(width, height);
        }
    }
}
