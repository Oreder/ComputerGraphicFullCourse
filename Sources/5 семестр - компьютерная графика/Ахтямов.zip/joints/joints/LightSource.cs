﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    public class LightSource
    {
        private TPoint position = new TPoint();
        private double Intense = 0;
        TransformMatrix transforms = new TransformMatrix();
        public LightSource()
        {
            position = new TPoint();
            Intense = 0;
        }
        public LightSource(TPoint _position, double _intense)
        {
            position = _position;
            Intense = _intense;
        }
        public void SetCoord(TPoint point)
        {
            position = point;
        }
        public void SetIntense(double value)
        {
            Intense = value;
        }
        public TPoint GetPosition()
        {
            return position.ToView(transforms);
        }
        public double GetIntense()
        {
            return Intense;
        }
        public double GetX()
        {
            return position.ToView(transforms).getX();
        }
        public double GetY()
        {
            return position.ToView(transforms).getY();
        }
        public double GetZ()
        {
            return position.ToView(transforms).getZ();
        }
        public void RotateX(double angle, TPoint point)
        {
            transforms.Move(-point.getX(), -point.getY(), -point.getZ());
            transforms.RotateX(angle);
            transforms.Move(point.getX(), point.getY(), point.getZ());
        }
        public void RotateY(double angle, TPoint point)
        {
            transforms.Move(-point.getX(), -point.getY(), -point.getZ());
            transforms.RotateY(angle);
            transforms.Move(point.getX(), point.getY(), point.getZ());
        }
        public void RotateZ(double angle, TPoint point)
        {
            transforms.Move(-point.getX(), -point.getY(), -point.getZ());
            transforms.RotateZ(angle);
            transforms.Move(point.getX(), point.getY(), point.getZ());
        }
        public void Scale(double k, TPoint center)
        {
            transforms.Move(-center.getX(), -center.getY(), -center.getZ());
            transforms.Scale(k, k, k);
            transforms.Move(center.getX(), center.getY(), center.getZ());
        }
        public void Move(double dx, double dy, double dz)
        {
            transforms.Move(dx, dy, dz);
        }
        public void MatrixRefresh()
        {
            transforms = new TransformMatrix();
        }
    }
    
}
