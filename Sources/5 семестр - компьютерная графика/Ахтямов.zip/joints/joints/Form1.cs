﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace joints
{
    public partial class Form1 : Form
    {
        private DataObject dataobject;
        //цилиндр
        public double cyl_radius = 35;
        public double cyl_height = 60;
        //конус
        public double cone_bottom_radius = 35;
        public double cone_top_radius = 20;
        public double cone_height = 60;
        //сфера
        public double sphere_radius = 35;
        //разбиение на треугольники объектов врещания
        public int round_segments = 40;
        public int height_segments = 3;
        // масштабирование
        public double scale = 1.5;
        // сдвиги камеры
        public double motions = 30;
        // угол поворота
        public double angle = Math.PI / 16;
        public double angle_camera = Math.PI / 16;
        // количество разбиений сочленения
        public int joint_round_segments = 40;
        public int joint_height_segments = 16;

        private int previous = -1;
        
        public Form1()
        {
            InitializeComponent();
            dataobject = new DataObject(pbCanvas.Width, pbCanvas.Height);
            ObjectsBox.SelectedIndex = 0;
            ObjectColorDialog.Color = Color.Red;
            textBoxColor.BackColor = ObjectColorDialog.Color;
        }
        private void BtnLightSource_Click(object sender, EventArgs e)
        {
            string str_x = light_x.Text;
            string str_y = light_y.Text;
            string str_z = light_z.Text;
            string light = intense.Text;
            double x = 0, y = 0, z = 0, ints = 0;
            try
            {
                x = Convert.ToDouble(str_x.Replace('.', ','));
                y = Convert.ToDouble(str_y.Replace('.', ','));
                z = Convert.ToDouble(str_z.Replace('.', ','));
                ints = Convert.ToDouble(light.Replace('.', ','));
            }
            catch (System.FormatException)
            {
                MessageBox.Show("Ошибка формата ввода параметров освещения");
                return;
            }
            if (ints > 1 || ints < 0)
            {
                MessageBox.Show("Значение интенсивности должно быть в пределах от 0 до 1");
                return;
            }
            Thread working_thread = new Thread(delegate()
            {
                dataobject.SetLight(x, y, z, ints);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }
        private void btnColor_Click(object sender, EventArgs e)
        {
            ObjectColorDialog.ShowDialog();
            textBoxColor.BackColor = ObjectColorDialog.Color;
        }

        private void btnAddItemUp_Click(object sender, EventArgs e)
        {
            switch(ObjectsBox.SelectedIndex)
            {
                case 0:
                    dataobject.AddCylinderUp(cyl_radius, cyl_height, ObjectColorDialog.Color, round_segments, height_segments);
                    break;
                case 1:
                    dataobject.AddConeUp(cone_bottom_radius, cone_top_radius, cone_height, ObjectColorDialog.Color, round_segments, height_segments);
                    break;
                case 2:
                    dataobject.AddConeUp(cone_bottom_radius, 0, cone_height, ObjectColorDialog.Color, round_segments, height_segments);
                    break;
            }
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnAddItemDown_Click(object sender, EventArgs e)
        {
            switch (ObjectsBox.SelectedIndex)
            { 
                case 0:
                    dataobject.AddCylinderDown(cyl_radius, cyl_height, ObjectColorDialog.Color, round_segments, height_segments);
                    break;
                case 1:
                    dataobject.AddConeDown(cone_bottom_radius, cone_top_radius, cone_height, ObjectColorDialog.Color, round_segments, height_segments);
                    break;
                case 2:
                    dataobject.AddConeDown(cone_bottom_radius, 0, cone_height, ObjectColorDialog.Color, round_segments, height_segments);
                    break;
            }
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnJointUp_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.AddSphereUp(sphere_radius, ObjectColorDialog.Color, joint_round_segments, joint_height_segments);
            });
            working_thread.Start();
            working_thread.Join();
            int num = dataobject.GetJointsAmount();
            listBoxJoints.Items.Clear();
            for (int i = 0; i < num; i++)
                listBoxJoints.Items.Add("Сочленение " + (i+1).ToString());
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnJointDown_Click(object sender, EventArgs e)
        {
            dataobject.AddSphereDown(sphere_radius, ObjectColorDialog.Color, joint_round_segments, joint_height_segments);
            int num = dataobject.GetJointsAmount();
            listBoxJoints.Items.Clear();
            for (int i = 0; i < num; i++)
                listBoxJoints.Items.Add("Сочленение " + (i + 1).ToString());
            pbCanvas.Image = dataobject.GetImage();
        }

        private void CameraUp_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.RotateCameraX(angle_camera);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void CameraDown_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.RotateCameraX(-angle_camera);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void CameraRight_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.RotateCameraY(angle_camera);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void CameraLeft_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.RotateCameraY(-angle_camera);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnScalePlus_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.Scale(scale);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();

        }

        private void btnScaleMinus_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.Scale(1 / scale);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnMoveCamUp_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.MoveCamera(0, motions, 0);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }
        

        private void btnMoveCamDown_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.MoveCamera(0, -motions, 0);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnMoveCamRight_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.MoveCamera(-motions, 0, 0);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnMoveCamLeft_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.MoveCamera(motions, 0, 0);
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnDelUp_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.RemoveTop();
                int num = dataobject.GetJointsAmount();
                listBoxJoints.Items.Clear();
                for (int i = 0; i < num; i++)
                    listBoxJoints.Items.Add("Сочленение " + (i + 1).ToString());
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void btnDelDown_Click(object sender, EventArgs e)
        {
            Thread working_thread = new Thread(delegate()
            {
                dataobject.RemoveBottom();
                int num = dataobject.GetJointsAmount();
                listBoxJoints.Items.Clear();
                for (int i = 0; i < num; i++)
                    listBoxJoints.Items.Add("Сочленение " + (i + 1).ToString());
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (listBoxJoints.SelectedIndex == -1)
                return;
            int index = listBoxJoints.SelectedIndex;
              Thread working_thread = new Thread(delegate()
              {
                if (radioButtonTop.Checked)
                {
                    switch (e.KeyCode)
                    {

                        case (Keys.X):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateXTop(index, -angle);
                            else
                                dataobject.RotateXTop(index, angle);
                            break;
                        case (Keys.Y):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateYTop(index, -angle);
                            else
                                dataobject.RotateYTop(index, angle);
                            break;
                        case (Keys.Z):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateZTop(index, -angle);
                            else
                                dataobject.RotateZTop(index, angle);
                            break;
                    }
                }
                else if (radioButtonBottom.Checked)
                {
                    switch (e.KeyCode)
                    {

                        case (Keys.X):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateXBottom(index, -angle);
                            else
                                dataobject.RotateXBottom(index, angle);
                            break;
                        case (Keys.Y):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateYBottom(index, -angle);
                            else
                                dataobject.RotateYBottom(index, angle);
                            break;
                        case (Keys.Z):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateZBottom(index, -angle);
                            else
                                dataobject.RotateZBottom(index, angle);
                            break;
                    }
                }
                else if (radioButtonAll.Checked)
                {
                    switch (e.KeyCode)
                    {

                        case (Keys.X):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateXAll(index, -angle);
                            else
                                dataobject.RotateXAll(index, angle);
                            break;
                        case (Keys.Y):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateYAll(index, -angle);
                            else
                                dataobject.RotateYAll(index, angle);
                            break;
                        case (Keys.Z):
                            if (e.Modifiers == Keys.Control)
                                dataobject.RotateZAll(index, -angle);
                            else
                                dataobject.RotateZAll(index, angle);
                            break;
                    }
                }
              });
              working_thread.Start();
              working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void tabView_MouseClick(object sender, MouseEventArgs e)
        {
            int index = listBoxJoints.SelectedIndex;
            Thread working_thread = new Thread(delegate()
            {
                int choice = index;
                if (choice == -1)
                    return;
                dataobject.UnchooseItem(choice);
                dataobject.Refresh();
            });
            working_thread.Start();
            working_thread.Join();
            listBoxJoints.ClearSelected();
            pbCanvas.Image = dataobject.GetImage();
            previous = -1;
        }

        private void listBoxJoints_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBoxJoints.SelectedIndex;
            Thread working_thread = new Thread(delegate()
            {
                int choice = index;
                if (choice == -1)
                    return;
                if (previous != -1)
                    dataobject.UnchooseItem(previous);
                dataobject.ChooseItem(choice);
                dataobject.Refresh();
                previous = choice;
            });
            working_thread.Start();
            working_thread.Join();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void параметрыОбъектовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSettings form = new FormSettings(this);
            form.Show();
        }

        private void параметрыРазбиенияНаТреугольникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Внимание! Уменьшение данных параметров может привести к искажению изображения, а увеличение к замедлению работы программы");
            FormSegmentsSettings form = new FormSegmentsSettings(this);
            form.Show();
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataobject.Clear();
            listBoxJoints.Items.Clear();
            pbCanvas.Image = dataobject.GetImage();
        }

        private void параметрыУгловПоворотаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAngleSettings form = new FormAngleSettings(this);
            form.Show();
        }

        private void pbCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            edtMousePosition.Text = e.X.ToString() + " ; " + e.Y.ToString();
        }

        private void pbCanvas_MouseLeave(object sender, EventArgs e)
        {
            edtMousePosition.Clear();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnumHelp value = new EnumHelp();
            value.info = HelpType.About;
            FormHelp form = new FormHelp(value);
            form.Show();
        }

        private void вкладкаМоделированиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnumHelp value = new EnumHelp();
            value.info = HelpType.Modeling;
            FormHelp form = new FormHelp(value);
            form.Show();
        }

        private void вкладкаОбзорToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnumHelp value = new EnumHelp();
            value.info = HelpType.View;
            FormHelp form = new FormHelp(value);
            form.Show();
        }

        private void клавишиУправленияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnumHelp value = new EnumHelp();
            value.info = HelpType.Keys;
            FormHelp form = new FormHelp(value);
            form.Show();
        }
    }
}
