﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace joints
{
    public partial class FormSettings : Form
    {
        Form1 form;
        public FormSettings(Form1 _form)
        {
            InitializeComponent();
            form = _form;
            edtConeBRadius.Text = form.cone_bottom_radius.ToString();
            edtConeTRadius.Text = form.cone_top_radius.ToString();
            edtConeHeight.Text = form.cone_height.ToString();
            edtCylHeight.Text = form.cyl_height.ToString();
            edtCylRadius.Text = form.cyl_radius.ToString();
            edtSphereRadius.Text = form.sphere_radius.ToString();
            btnFix.Enabled = false;
        }

        private void edtCylHeight_TextChanged(object sender, EventArgs e)
        {
            btnFix.Enabled = true;
        }

        private void btnFix_Click(object sender, EventArgs e)
        {
            try
            {
                form.cone_bottom_radius = Convert.ToDouble(edtConeBRadius.Text);
                form.cone_top_radius = Convert.ToDouble(edtConeTRadius.Text);
                form.cone_height = Convert.ToDouble(edtConeHeight.Text);
                form.cyl_height = Convert.ToDouble(edtCylHeight.Text);
                form.cyl_radius = Convert.ToDouble(edtCylRadius.Text);
                form.sphere_radius = Convert.ToDouble(edtSphereRadius.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Проверьте корректность введенных данных. Дробная часть числа должна отделяться от целой запятой");
                return;
            }
            this.Close();
        }

        private void btnDefault_Click(object sender, EventArgs e)
        {
            edtConeBRadius.Text = "35";
            edtConeTRadius.Text = "20";
            edtConeHeight.Text = "60";
            edtCylHeight.Text = "60";
            edtCylRadius.Text = "35";
            edtSphereRadius.Text = "35";
        }
    }
}
