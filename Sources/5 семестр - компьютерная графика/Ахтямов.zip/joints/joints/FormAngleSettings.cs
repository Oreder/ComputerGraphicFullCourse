﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace joints
{
    public partial class FormAngleSettings : Form
    {
        Form1 form;
        public FormAngleSettings(Form1 _form)
        {
            InitializeComponent();
            form = _form;
            edtAngle.Text = (form.angle / Math.PI * 180).ToString();
            edtCameraAngle.Text = (form.angle_camera / Math.PI * 180).ToString();
            edtMotions.Text = form.motions.ToString();
            btnFix.Enabled = false;
        }

        private void edtAngle_TextChanged(object sender, EventArgs e)
        {
            btnFix.Enabled = true;
        }

        private void btnDefault_Click(object sender, EventArgs e)
        {
            edtAngle.Text = ((double)1 / 16 * 180).ToString();
            edtCameraAngle.Text = ((double)1 / 16 * 180).ToString();
            edtMotions.Text = "30";
        }

        private void btnFix_Click(object sender, EventArgs e)
        {
            try
            {
                form.angle = Convert.ToDouble(edtAngle.Text) / 180 * Math.PI;
                form.angle_camera = Convert.ToDouble(edtCameraAngle.Text) / 180 * Math.PI;
                form.motions = Convert.ToDouble(edtMotions.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Проверьте корректность введенных данных. Дробная часть числа должна отделяться от целой запятой");
                return;
            }
            Close();
        }
    }
}
