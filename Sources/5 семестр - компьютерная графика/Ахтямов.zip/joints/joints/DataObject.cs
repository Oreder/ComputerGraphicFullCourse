﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace joints
{
    class DataObject
    {
        private JointedObject JObject = new JointedObject();
        private ZBuffer zbuffer;
        private TPoint center;
        private List<int> Joints_idx = new List<int>();
        private List<TPoint> tops = new List<TPoint>();
        private List<TPoint> bottoms = new List<TPoint>();
        TransformMatrix transforms = new TransformMatrix();
        Color temp_color;
        public DataObject(int width, int height)
        {
            zbuffer = new ZBuffer(width, height);
            zbuffer.initialize();
            center = new TPoint(width / 2, height / 2, 0);
        }
        public Bitmap GetImage()
        {
            return zbuffer.GetBitmap();
        }
        public void SetLight(double x, double y, double z, double intensity)
        {
            zbuffer.refresh();
            JObject.SetLight(new LightSource(new TPoint(x, y, z), intensity));
            JObject.Draw();
        }
        public void AddCylinderUp(double radius, double height, Color _color, int round_segments, int height_sements)
        {
            double x = zbuffer.get_width() / 2, y = 0, z = 0;
            if (tops.Count == 0)
                y = zbuffer.get_heigth() / 2 + height / 2;
            else
                y = tops[tops.Count - 1].getY();
            Cylinder obj = new Cylinder(new TPoint(x, y, z), radius, height);
            obj.SetZBuffer(zbuffer);
            obj.SetColor(_color);
            obj.SetTransformMatrix(transforms);
            JObject.AppendCylinder(obj, round_segments, height_sements);
            TPoint _bottom = new TPoint(x, y, z);
            TPoint _top = new TPoint(x, y-height, z);
            bottoms.Add(_bottom);
            tops.Add(_top);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void AddCylinderDown(double radius, double height, Color _color, int round_segments, int height_sements)
        {
            double x = zbuffer.get_width() / 2, y = 0, z = 0;
            if (tops.Count == 0)
            {
                y = zbuffer.get_heigth() / 2 + height;
            }
            else
                y = bottoms[0].getY() +height;
            Cylinder obj = new Cylinder(new TPoint(x, y, z), radius, height);
            obj.SetZBuffer(zbuffer);
            obj.SetColor(_color);
            obj.SetTransformMatrix(transforms);
            JObject.AddCylinder(obj, round_segments, height_sements);
            TPoint _bottom = new TPoint(x, y, z);
            TPoint _top = new TPoint(x, y - height, z);
            bottoms.Insert(0, _bottom);
            tops.Insert(0, _top);
            IncJointsList();
            zbuffer.refresh();
            JObject.Draw();
        }

        public void AddConeUp(double bottom_radius, double top_radius, double height, Color _color, int round_segments, int height_sements)
        {
            double x = zbuffer.get_width() / 2, y = 0, z = 0;
            if (tops.Count == 0)
                y = zbuffer.get_heigth() / 2 + height / 2;
            else
                y = tops[tops.Count - 1].getY();
            Cone obj = new Cone(new TPoint(x, y, z), bottom_radius, new TPoint(x, y - height, z), top_radius);
            obj.SetZBuffer(zbuffer);
            obj.SetColor(_color);
            obj.SetTransformMatrix(transforms);
            JObject.AppendCone(obj, round_segments, height_sements);
            TPoint _bottom = new TPoint(x, y, z);
            TPoint _top = new TPoint(x, y - height, z);
            bottoms.Add(_bottom);
            tops.Add(_top);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void AddConeDown(double bottom_radius, double top_radius, double height, Color _color, int round_segments, int height_sements)
        {
            double x = zbuffer.get_width() / 2, y = 0, z = 0;
            if (tops.Count == 0)
                y = zbuffer.get_heigth() / 2 + height;
            else
                y = bottoms[0].getY() + height;
            Cone obj = new Cone(new TPoint(x, y, z), bottom_radius, new TPoint(x, y-height, z), top_radius);
            obj.SetZBuffer(zbuffer);
            obj.SetColor(_color);
            obj.SetTransformMatrix(transforms);
            JObject.AddCone(obj, round_segments, height_sements);
            TPoint _bottom = new TPoint(x, y, z);
            TPoint _top = new TPoint(x, y - height, z);
            bottoms.Insert(0, _bottom);
            tops.Insert(0, _top);
            IncJointsList();
            zbuffer.refresh();
            JObject.Draw();
        }
        public void AddSphereUp(double radius, Color _color, int round_segments, int height_segments)
        {
            double x = zbuffer.get_width() / 2, y = 0, z = 0;
            if (tops.Count == 0)
            {
                y = zbuffer.get_heigth() / 2;
            }
            else
                y = tops[tops.Count-1].getY() - radius;
            Sphere obj = new Sphere(new TPoint(x, y, z), radius);
            obj.SetColor(_color);
            obj.SetZBuffer(zbuffer);
            obj.SetTransformMatrix(transforms);
            JObject.AppendSphere(obj, round_segments, height_segments);
            TPoint _bottom = new TPoint(x, y + radius, z);
            TPoint _top = new TPoint(x, y - radius, z);
            bottoms.Add(_bottom);
            tops.Add(_top);
            Joints_idx.Add(JObject.Size() - 1);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void AddSphereDown(double radius, Color _color, int round_segments, int height_segments)
        {
            double x = zbuffer.get_width() / 2, y = 0, z = 0;
            if (tops.Count == 0)
            {
                y = zbuffer.get_heigth() / 2;
            }
            else
                y = bottoms[0].getY() + radius;
            Sphere obj = new Sphere(new TPoint(x, y, z), radius);
            obj.SetColor(_color);
            obj.SetZBuffer(zbuffer);
            obj.SetTransformMatrix(transforms);
            JObject.AddSphere(obj, round_segments, height_segments);
            TPoint _bottom = new TPoint(x, y + radius, z);
            TPoint _top = new TPoint(x, y - radius, z);
            bottoms.Insert(0, _bottom);
            tops.Insert(0, _top);
            IncJointsList();
            Joints_idx.Insert(0, 0);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RemoveTop()
        {
            JObject.RemoveTop();
            if (tops.Count > 0)
            {
                tops.RemoveAt(tops.Count - 1);
                bottoms.RemoveAt(bottoms.Count - 1);
                if (Joints_idx.Count > 0 && Joints_idx[Joints_idx.Count - 1] == JObject.Size())
                    Joints_idx.RemoveAt(Joints_idx.Count - 1);
                zbuffer.refresh();
                JObject.Draw();
            }
        }
        public void RemoveBottom()
        {
            JObject.RemoveBottom();
            if (tops.Count > 0)
            {
                tops.RemoveAt(0);
                bottoms.RemoveAt(0);
                DecJointsList();
                if (Joints_idx.Count > 0 && Joints_idx[0] == -1)
                    Joints_idx.RemoveAt(0);
                zbuffer.refresh();
                JObject.Draw();
            }
        }
        protected void IncJointsList()
        {
            for (int i = 0; i < Joints_idx.Count; i++ )
                ++Joints_idx[i];
        }
        protected void DecJointsList()
        {
            for (int i = 0; i < Joints_idx.Count; i++)
                --Joints_idx[i];
        }
        #region Camera
        public void RotateCameraX(double angle)
        {
            JObject.RotateCameraX(center, angle);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateCameraY(double angle)
        {
            JObject.RotateCameraY(center, angle);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void Scale(double k)
        {
            JObject.Scale(center, k);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void MoveCamera(double dx, double dy, double dz)
        {
            transforms.Move(dx, dy, dz);
            JObject.MoveCamera(dx, dy, dz);
            zbuffer.refresh();
            JObject.Draw();
        }
    #endregion
        #region Rotations
        public void RotateXTop(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateXUpper(center, angle, item_index);
            if (JObject.Collisions())
            {
                MessageBox.Show("Произошло пересечение объектов сцены. Поворот не будет совершен");
                JObject.RotateXUpper(center, -angle, item_index);
            }
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateYTop(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateYUpper(center, angle, item_index);
            if (JObject.Collisions())
            {
                MessageBox.Show("Произошло пересечение объектов сцены. Поворот не будет совершен");
                JObject.RotateYUpper(center, -angle, item_index);
            }
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateZTop(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateZUpper(center, angle, item_index);
            if (JObject.Collisions())
            {
                MessageBox.Show("Произошло пересечение объектов сцены. Поворот не будет совершен");
                JObject.RotateZUpper(center, -angle, item_index);
            }
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateXBottom(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateXUnder(center, angle, item_index);
            if (JObject.Collisions())
            {
                MessageBox.Show("Произошло пересечение объектов сцены. Поворот не будет совершен");
                JObject.RotateXUnder(center, -angle, item_index);
            }
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateYBottom(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateYUnder(center, angle, item_index);
            if (JObject.Collisions())
            {
                MessageBox.Show("Произошло пересечение объектов сцены. Поворот не будет совершен");
                JObject.RotateYUnder(center, -angle, item_index);
            }
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateZBottom(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateZUnder(center, angle, item_index);
            if (JObject.Collisions())
            {
                MessageBox.Show("Произошло пересечение объектов сцены. Поворот не будет совершен");
                JObject.RotateZUnder(center, -angle, item_index);
            }
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateXAll(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateXAll(center, angle, item_index);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateYAll(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateYAll(center, angle, item_index);
            zbuffer.refresh();
            JObject.Draw();
        }
        public void RotateZAll(int index, double angle)
        {
            int item_index = Joints_idx[index];
            TPoint center = JObject.Middle(item_index);
            JObject.RotateZAll(center, angle, item_index);
            zbuffer.refresh();
            JObject.Draw();
        }
        #endregion
        public int GetJointsAmount()
        {
            return Joints_idx.Count;
        }
        public void Refresh()
        {
            JObject.Draw();
        }
        public void ChooseItem(int index)
        {
            int item_index = Joints_idx[index];
            temp_color = JObject.GetColor(item_index);
            JObject.SetColor(Color.Black, item_index);
            JObject.Draw();
            
        }
        public void UnchooseItem(int index)
        {
            int item_index = Joints_idx[index];
            JObject.SetColor(temp_color, item_index);
            JObject.Draw();
        }
        public void Clear()
        {
            JObject.Clear();
            tops.Clear();
            bottoms.Clear();
            Joints_idx.Clear();
            transforms = new TransformMatrix();
            zbuffer.refresh();
            JObject.Draw();
        }
    }
}