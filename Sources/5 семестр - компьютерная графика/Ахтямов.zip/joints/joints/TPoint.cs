﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace joints
{
    public class TPoint
    {
        private double x;
        private double y;
        private double z;
        private Color color = Color.Black;

        #region Construct
        public TPoint()
        {
            x = 0; y = 0; z = 0;
        }
        public TPoint(int vx, int vy, int vz)
        {
            x = vx;
            y = vy;
            z = vz;
        }

        public TPoint(double vx, double vy, double vz)
        {
            x = vx;
            y = vy;
            z = vz;
        }
        public TPoint(double vx, double vy, double vz, Color _color)
        {
            x = vx;
            y = vy;
            z = vz;
            color = _color;
        }
        #endregion

        #region set_get
        public void setX(double value)
        {
            x = value;
        }

        public void setY(double value)
        {
            y = value;
        }

        public void setZ(double value)
        {
            z = value;
        }

        public void setColor(Color clr)
        {
            color = clr;
        }
       
        // получение координат
        public double getX()
        {
            return x;
        }

        public double getY()
        {
            return y;
        }

        public double getZ()
        {
            return z;
        }

        public int getIntX()
        {
            return (int)Math.Floor(x + 0.5);
        }

        public int getIntY()
        {
            return (int)Math.Floor(y + 0.5);
        }

        public int getIntZ()
        {
            return (int)Math.Floor(z + 0.5);
        }

        public Color getColor()
        {
            return color;
        }
        #endregion

        public bool Equals(TPoint point)
        {
            if (x == point.getX() && y == point.getY() && z == point.getZ())
                return true;
            return false;
        }

        public double delta(TPoint point)
        {
            return Math.Sqrt(Math.Pow(x - point.getX(), 2) + Math.Pow(y - point.getY(), 2));// +pow(z - point->getZ(), 2));
        }

        public void MiddlePoint(TPoint point1, TPoint point2)
        {
            x = (point1.getX() + point2.getX()) / 2;
            y = (point1.getY() + point2.getY()) / 2;
            z = (point1.getZ() + point2.getZ()) / 2 ;
        }
        
        public TPoint ToView(TransformMatrix view)
        {
            
            TPoint vp = new TPoint();
            vp.setX(x * view.matrix[0,0] + y * view.matrix[1,0] + 
                z * view.matrix[2,0] + view.matrix[3, 0] );
            vp.setY(x * view.matrix[0, 1] + y * view.matrix[1, 1] +
                z * view.matrix[2, 1] + view.matrix[3, 1]);
            vp.setZ(x * view.matrix[0, 2] + y * view.matrix[1, 2] +
                z * view.matrix[2, 2] + view.matrix[3, 2]);
            return vp;
        }
        public TPoint AddVector(Vector vector)
        {
            TPoint point = new TPoint();
            point.setX(x + vector.GetX());
            point.setY(y + vector.GetY());
            point.setZ(z + vector.GetZ());
            return point;
        }
    }
}
