﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    class Sphere : AbstractObject
    {
        TPoint center;
        double radius;
        public Sphere(TPoint _point, double _radius)
        {
            center = _point;
            radius = _radius;
            MiddlePoint = center;
        }
        public void Triangulate(int round_segments, int height_segments)
        {
            List<Cone> cones = new List<Cone>();
            double angle = Math.PI * 2 / round_segments;
            double dy = radius * 2 / height_segments;
            double y = center.getY() + radius;
            for (int i = 0; i < height_segments / 2; i++)
            {
                double curr_y = y - dy * i;
                double r_bottom = Math.Sqrt(radius * radius - Math.Pow(curr_y - center.getY(), 2));
                curr_y = y - dy * (i + 1);
                double r_top = Math.Sqrt(radius * radius - Math.Pow(curr_y - center.getY(), 2));
                Cone obj = new Cone(new TPoint(center.getX(), y - dy * i, center.getZ()), r_bottom,
                    new TPoint(center.getX(), y - dy * (i + 1), center.getZ()), r_top);
                cones.Add(obj);
            }
            y = center.getY();
            for (int i = height_segments / 2; i < height_segments; i++)
            {
                double curr_y = y - dy * (i - height_segments / 2);
                double r_bottom = Math.Sqrt(radius * radius - Math.Pow(curr_y - center.getY(), 2));
                curr_y = y - dy * (i + 1 - height_segments / 2);
                double r_top = Math.Sqrt(radius * radius - Math.Pow(curr_y - center.getY(), 2));
                Cone obj = new Cone(new TPoint(center.getX(), y - dy * (i - height_segments / 2), center.getZ()), r_bottom,
                    new TPoint(center.getX(), y - dy * (i + 1 - height_segments / 2), center.getZ()), r_top);
                cones.Add(obj);
            }
            for (int i = 0; i < cones.Count; i++ )
            {
                if (i == 0 || i == cones.Count - 1)
                    cones[i].Triangulate(round_segments, 2, true);
                else
                    cones[i].Triangulate(round_segments, 2, false);
                List<Triangle> tmp = cones[i].GetTriangles();
                foreach (var elem in tmp)
                    container.Add(elem);
            }
            foreach (var item in container)
            {
                item.setZbuffer(zbuffer);
                item.setColor(color);
            }
        }
    }
}
