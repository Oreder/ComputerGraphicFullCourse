﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Threading;

namespace joints
{
    public class Triangle
    {
        public TPoint p1;
        public TPoint p2;
        public TPoint p3;
        private ZBuffer zbuffer;
        public double middleZ;
        private Vector triang_normal;
        public TPoint p1_end = new TPoint(), p2_end = new TPoint(), p3_end = new TPoint();

        #region Construct
        public Triangle(TPoint pp1, TPoint pp2, TPoint pp3)
        {
            set_points(pp1, pp2, pp3);
            middleZ = (double)(p1.getZ() + p2.getZ() + p3.getZ()) / 3;
            TriangleNormal();
        }
        #endregion

        public Vector GetNormal()
        {
            return triang_normal;
        }
        public void setColor(Color _color)
        {
            p1.setColor(_color);
            p2.setColor(_color);
            p3.setColor(_color);
        }
        public void TriangleNormal()
        {
            Vector side1 = new Vector(p1, p2);
            Vector side2 = new Vector(p2, p3);
            triang_normal = side1.Normal(side2);
            if (triang_normal.GetZ() > 0)
                triang_normal.Negate();
        }
        public void setZbuffer(ZBuffer _z)
        {
            zbuffer = _z;
        }
        public void set_points(TPoint _point1, TPoint _point2, TPoint _point3)
        {
            p1 = _point1;
            p2 = _point2;
            p3 = _point3;
        }

        public void Draw(TransformMatrix transform, LightSource source)
        {
            TPoint _p1 = p1.ToView(transform);
            TPoint _p2 = p2.ToView(transform);
            TPoint _p3 = p3.ToView(transform);
            if (_p1.getY() == _p2.getY() &&
                _p2.getY() == _p3.getY())
                return;
            Sort(transform);
            PaintGuro(transform, source);
        }

        public void Sort(TransformMatrix transform)      
        {
            if (p1.ToView(transform).getY() > p2.ToView(transform).getY())
            {
                TPoint tmp = p2;
                p2 = p1;
                p1 = tmp;
                tmp = p2_end;
                p2_end = p1_end;
                p1_end = tmp;
            }
            if (p2.ToView(transform).getY() > p3.ToView(transform).getY())
            {
                TPoint tmp = p3;
                p3 = p2;
                p2 = tmp;
                tmp = p3_end;
                p3_end = p2_end;
                p2_end = tmp;
            }
            if (p1.ToView(transform).getY() > p2.ToView(transform).getY())
            {
                TPoint tmp = p2;
                p2 = p1;
                p1 = tmp;
                tmp = p2_end;
                p2_end = p1_end;
                p1_end = tmp;
            }
        }

        #region Guro
        private double[] SetIntense(TransformMatrix transform, LightSource source)
        {
            double const_light = 0.3;
            TPoint _p1 = p1.ToView(transform);
            TPoint _p2 = p2.ToView(transform);
            TPoint _p3 = p3.ToView(transform);
            TPoint _p1_end = p1_end.ToView(transform);
            TPoint _p2_end = p2_end.ToView(transform);
            TPoint _p3_end = p3_end.ToView(transform);

            Vector[] toP = new Vector[3];
            TPoint src_pos = source.GetPosition();
            toP[0] = new Vector(src_pos, _p1);
            toP[1] = new Vector(src_pos, _p2);
            toP[2] = new Vector(src_pos, _p3);
            Vector[] normals = new Vector[3];
            normals[0] = new Vector(_p1, _p1_end);
            normals[1] = new Vector(_p2, _p2_end);
            normals[2] = new Vector(_p3, _p3_end);
            for (int i = 0; i < 3; i++)
            {
                normals[i].Normalize();
                if (normals[i].GetZ() > 0)
                    normals[i].Negate();
            }
            double[] intense = new double[3];
            double[] angle_cos = new double[3];
            for (int i = 0; i < 3; i++)
            {
                angle_cos[i] = toP[i].Cos(normals[i]);
                intense[i] = angle_cos[i] * source.GetIntense() + const_light;
                if (intense[i] > 1)
                    intense[i] = 1;
                else if (intense[i] < const_light)
                    intense[i] = const_light;
            }
            return intense;
        }
        public void PaintGuro(TransformMatrix transform, LightSource source)
        {
            double [] intense = SetIntense(transform, source);
            TPoint _point1 = p1.ToView(transform);
            TPoint _point2 = p2.ToView(transform);
            TPoint _point3 = p3.ToView(transform);
            PointAndIntens _1 = new PointAndIntens(_point1, intense[0]);
            PointAndIntens _2 = new PointAndIntens(_point2, intense[1]);
            PointAndIntens _3 = new PointAndIntens(_point3, intense[2]);

            PointAndIntens[] points = new PointAndIntens[3] { _1, _2, _3 };

            int _p1 = 0;
            int _p2 = 0;
            int start = 0;
            int end = 0;
            double iQ = 0;
            double iR = 0;
            double iP = 0;

            double length12 = _point2.getY() - _point1.getY();
            double length23 = _point3.getY() - _point2.getY();
            double length13 = _point3.getY() - _point1.getY();

            double dz12 = 0, dz23 = 0, dz13 = 0;
            if (length12 > 0)
                dz12 = (_point2.getZ() - _point1.getZ()) / length12;
            if (length13 > 0)
                dz13 = (_point3.getZ() - _point1.getZ()) / length13;
            if (length23 > 0)
                dz23 = (_point3.getZ() - _point2.getZ()) / length23;

            double z_left = 0, z_right = 0;
            #region первая секция
            if (points[0].Point.getIntY() != points[1].Point.getIntY())
            {
                double length1 = Math.Sqrt(Math.Pow((points[0].Point.getX() - points[1].Point.getX()), 2) +
                                    Math.Pow((points[0].Point.getY() - points[1].Point.getY()), 2));

                double length2 = Math.Sqrt(Math.Pow((points[0].Point.getX() - points[2].Point.getX()), 2) +
                                    Math.Pow((points[0].Point.getY() - points[2].Point.getY()), 2));

                for (int y = points[0].Point.getIntY(); y < points[1].Point.getIntY() + 1; y++)
                {
                    _p1 = (int)((y - points[0].Point.getIntY()) * (points[1].Point.getIntX() - points[0].Point.getIntX()) / (points[1].Point.getIntY() - points[0].Point.getIntY())) + points[0].Point.getIntX();
                    _p2 = (int)((y - points[0].Point.getIntY()) * (points[2].Point.getIntX() - points[0].Point.getIntX()) / (points[2].Point.getIntY() - points[0].Point.getIntY())) + points[0].Point.getIntX();

                    if (_p1 > _p2)
                    {
                        start = _p2;
                        end = _p1;

                        double len1 = Math.Sqrt(Math.Pow((_p2 - points[0].Point.getX()), 2) + Math.Pow((y - points[0].Point.getY()), 2));
                        double len2 = Math.Sqrt(Math.Pow((_p1 - points[0].Point.getX()), 2) + Math.Pow((y - points[0].Point.getY()), 2));

                        iQ = (1 - (len1 / length2)) * points[0].Intensity + (len1 / length2) * points[2].Intensity;
                        iR = (1 - (len2 / length1)) * points[0].Intensity + (len2 / length1) * points[1].Intensity;

                    }
                    else
                    {
                        start = _p1;
                        end = _p2;

                        double len1 = Math.Sqrt(Math.Pow((_p2 - points[0].Point.getX()), 2) + Math.Pow((y - points[0].Point.getY()), 2));
                        double len2 = Math.Sqrt(Math.Pow((_p1 - points[0].Point.getX()), 2) + Math.Pow((y - points[0].Point.getY()), 2));

                        iQ = (1 - (len2 / length1)) * points[0].Intensity + (len2 / length1) * points[1].Intensity;
                        iR = (1 - (len1 / length2)) * points[0].Intensity + (len1 / length2) * points[2].Intensity;
                    }

                    if (_point2.getX() < _point3.getX())
                    {
                        z_left = _point1.getZ() + dz12 * (y - _point1.getY());
                        z_right = _point1.getZ() + dz13 * (y - _point1.getY());
                    }
                    else
                    {
                        z_left = _point1.getZ() + dz13 * (y - _point1.getY());
                        z_right = _point1.getZ() + dz12 * (y - _point1.getY());
                    }

                    double dzx = 0;
                    if (end != start)
                        dzx = (z_right - z_left) / (end - start);
                    for (int x = start; x <= end; x++)
                    {
                        if (x <= 0 || y <= 0 || x >= zbuffer.get_width() || y >= zbuffer.get_heigth())
                            break;
                        double lengthQR = Math.Sqrt(Math.Pow((end - start), 2));
                        double lengthQP = Math.Sqrt(Math.Pow((x - start), 2));
                        double z = z_left + dzx * (x - start);
                        if (z < zbuffer.getZ(x, y))
                        {
                            zbuffer.setZ(x, y, (int)z);
                            if (lengthQR == 0)
                            {
                                iP = iR;
                            }
                            else
                            {
                                iP = (1 - (lengthQP / lengthQR)) * iQ + (lengthQP / lengthQR) * iR;
                            }
                            iP = iP < 1 ? iP : 1;
                            iP = iP > 0 ? iP : 0;
                            zbuffer.setColor(x, y, Color.FromArgb((int)(p1.getColor().R * iP), (int)(p1.getColor().G * iP), (int)(p1.getColor().B * iP)));
                        }
                    }
                }
            }
            #endregion

            #region вторая секция
                    if (points[1].Point.getIntY() != points[2].Point.getIntY())
                    {
                        double length1 = Math.Sqrt(Math.Pow((points[2].Point.getX() - points[1].Point.getX()), 2) +
                                            Math.Pow((points[2].Point.getY() - points[1].Point.getY()), 2));

                        double length2 = Math.Sqrt(Math.Pow((points[2].Point.getX() - points[0].Point.getX()), 2) +
                                            Math.Pow((points[2].Point.getY() - points[0].Point.getY()), 2));

                        for (int y = points[1].Point.getIntY(); y < points[2].Point.getIntY() + 1; y++)
                        {
                            _p1 = (int)((y - points[2].Point.getIntY()) * (points[1].Point.getIntX() - points[2].Point.getIntX()) / (points[1].Point.getIntY() - points[2].Point.getIntY())) + points[2].Point.getIntX();
                            _p2 = (int)((y - points[2].Point.getIntY()) * (points[0].Point.getIntX() - points[2].Point.getIntX()) / (points[0].Point.getIntY() - points[2].Point.getIntY())) + points[2].Point.getIntX();

                            if (_p1 >= _p2)
                            {
                                start = _p2;
                                end = _p1;

                                double len1 = Math.Sqrt(Math.Pow((_p2 - points[0].Point.getX()), 2) + Math.Pow((y - points[0].Point.getY()), 2));
                                double len2 = Math.Sqrt(Math.Pow((_p1 - points[1].Point.getX()), 2) + Math.Pow((y - points[1].Point.getY()), 2));

                                iQ = (1 - (len1 / length2)) * points[0].Intensity + (len1 / length2) * points[2].Intensity;
                                iR = (1 - (len2 / length1)) * points[1].Intensity + (len2 / length1) * points[2].Intensity;

                            }
                            else
                            {
                                start = _p1;
                                end = _p2;

                                double len1 = Math.Sqrt(Math.Pow((_p2 - points[0].Point.getX()), 2) + Math.Pow((y - points[0].Point.getY()), 2));
                                double len2 = Math.Sqrt(Math.Pow((_p1 - points[1].Point.getX()), 2) + Math.Pow((y - points[1].Point.getY()), 2));

                                iQ = (1 - (len2 / length1)) * points[1].Intensity + (len2 / length1) * points[2].Intensity;
                                iR = (1 - (len1 / length2)) * points[0].Intensity + (len1 / length2) * points[2].Intensity;

                            }

                            if (_point2.getZ() < _point3.getZ())
                            {
                                z_left = _point2.getZ() + dz23 * (y - _point2.getY());
                                z_right = _point1.getZ() + dz13 * (y - _point1.getY());
                            }
                            else
                            {
                                z_left = _point1.getZ() + dz13 * (y - _point1.getY());
                                z_right = _point2.getZ() + dz23 * (y - _point2.getY());
                            }

                            double dzx = 0;
                            if (end != start)
                                dzx = (z_right - z_left) / (end - start);

                            for (int x = start; x <= end; x++)
                            {
                                if (x <= 0 || y <= 0 || x >= zbuffer.get_width() || y >= zbuffer.get_heigth())
                                    break;
                                double lengthQR = Math.Sqrt(Math.Pow((end - start), 2));
                                double lengthQP = Math.Sqrt(Math.Pow((x - start), 2));
                                double z = z_left + dzx * (x - start);
                                if (z < zbuffer.getZ(x, y))
                                {
                                    zbuffer.setZ(x, y, (int)z);
                                    if (lengthQR == 0)
                                    {
                                        iP = iR;
                                    }
                                    else
                                    {
                                        iP = (1 - (lengthQP / lengthQR)) * iQ + ((lengthQP / lengthQR)) * iR;
                                    }
                                    iP = iP < 1 ? iP : 1;
                                    iP = iP > 0 ? iP : 0;
                                    zbuffer.setColor(x, y, Color.FromArgb((int)(p1.getColor().R * iP), (int)(p1.getColor().G * iP), (int)(p1.getColor().B * iP)));
                                }
                            }
                        }
                    }
            #endregion
        }
        
        #endregion
    }

    public class PointAndIntens
    {
        TPoint point;
        double intensity;

        public PointAndIntens(TPoint point, double intens)
        {
            this.point = point;
            this.intensity = intens;
        }

        public TPoint Point
        {
            get { return point; }
        }
        public double Intensity
        {
            get { return intensity; }
            set { intensity = value; }
        }
    }
}