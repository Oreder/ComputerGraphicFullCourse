﻿namespace joints
{
    partial class FormSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFix = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.edtCylHeight = new System.Windows.Forms.TextBox();
            this.edtCylRadius = new System.Windows.Forms.TextBox();
            this.edtConeHeight = new System.Windows.Forms.TextBox();
            this.edtConeBRadius = new System.Windows.Forms.TextBox();
            this.edtConeTRadius = new System.Windows.Forms.TextBox();
            this.edtSphereRadius = new System.Windows.Forms.TextBox();
            this.btnDefault = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnFix
            // 
            this.btnFix.Enabled = false;
            this.btnFix.Location = new System.Drawing.Point(181, 283);
            this.btnFix.Name = "btnFix";
            this.btnFix.Size = new System.Drawing.Size(90, 23);
            this.btnFix.TabIndex = 0;
            this.btnFix.Text = "Применить";
            this.btnFix.UseVisualStyleBackColor = true;
            this.btnFix.Click += new System.EventHandler(this.btnFix_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Высота цилиндра";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Высота конуса";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Радиус сферы";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Радиус цилиндра";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Радиус основания конуса";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(12, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(167, 30);
            this.label6.TabIndex = 1;
            this.label6.Text = "Радиус верхнего основания конуса (усеченного)";
            // 
            // edtCylHeight
            // 
            this.edtCylHeight.Location = new System.Drawing.Point(171, 20);
            this.edtCylHeight.Name = "edtCylHeight";
            this.edtCylHeight.Size = new System.Drawing.Size(100, 20);
            this.edtCylHeight.TabIndex = 2;
            this.edtCylHeight.TextChanged += new System.EventHandler(this.edtCylHeight_TextChanged);
            // 
            // edtCylRadius
            // 
            this.edtCylRadius.Location = new System.Drawing.Point(171, 49);
            this.edtCylRadius.Name = "edtCylRadius";
            this.edtCylRadius.Size = new System.Drawing.Size(100, 20);
            this.edtCylRadius.TabIndex = 3;
            this.edtCylRadius.TextChanged += new System.EventHandler(this.edtCylHeight_TextChanged);
            // 
            // edtConeHeight
            // 
            this.edtConeHeight.Location = new System.Drawing.Point(171, 98);
            this.edtConeHeight.Name = "edtConeHeight";
            this.edtConeHeight.Size = new System.Drawing.Size(100, 20);
            this.edtConeHeight.TabIndex = 4;
            this.edtConeHeight.TextChanged += new System.EventHandler(this.edtCylHeight_TextChanged);
            // 
            // edtConeBRadius
            // 
            this.edtConeBRadius.Location = new System.Drawing.Point(171, 130);
            this.edtConeBRadius.Name = "edtConeBRadius";
            this.edtConeBRadius.Size = new System.Drawing.Size(100, 20);
            this.edtConeBRadius.TabIndex = 5;
            this.edtConeBRadius.TextChanged += new System.EventHandler(this.edtCylHeight_TextChanged);
            // 
            // edtConeTRadius
            // 
            this.edtConeTRadius.Location = new System.Drawing.Point(171, 163);
            this.edtConeTRadius.Name = "edtConeTRadius";
            this.edtConeTRadius.Size = new System.Drawing.Size(100, 20);
            this.edtConeTRadius.TabIndex = 6;
            this.edtConeTRadius.TextChanged += new System.EventHandler(this.edtCylHeight_TextChanged);
            // 
            // edtSphereRadius
            // 
            this.edtSphereRadius.Location = new System.Drawing.Point(171, 213);
            this.edtSphereRadius.Name = "edtSphereRadius";
            this.edtSphereRadius.Size = new System.Drawing.Size(100, 20);
            this.edtSphereRadius.TabIndex = 7;
            this.edtSphereRadius.TextChanged += new System.EventHandler(this.edtCylHeight_TextChanged);
            // 
            // btnDefault
            // 
            this.btnDefault.Location = new System.Drawing.Point(181, 249);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(90, 23);
            this.btnDefault.TabIndex = 11;
            this.btnDefault.Text = "По умолчанию";
            this.btnDefault.UseVisualStyleBackColor = true;
            this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
            // 
            // FormSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 318);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.edtSphereRadius);
            this.Controls.Add(this.edtConeTRadius);
            this.Controls.Add(this.edtConeBRadius);
            this.Controls.Add(this.edtConeHeight);
            this.Controls.Add(this.edtCylRadius);
            this.Controls.Add(this.edtCylHeight);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFix);
            this.Name = "FormSettings";
            this.Text = "Параметры объектов";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFix;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox edtCylHeight;
        private System.Windows.Forms.TextBox edtCylRadius;
        private System.Windows.Forms.TextBox edtConeHeight;
        private System.Windows.Forms.TextBox edtConeBRadius;
        private System.Windows.Forms.TextBox edtConeTRadius;
        private System.Windows.Forms.TextBox edtSphereRadius;
        private System.Windows.Forms.Button btnDefault;
    }
}