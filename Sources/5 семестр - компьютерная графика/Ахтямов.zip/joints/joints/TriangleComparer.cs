﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    public class TriangleComparer : IComparer<Triangle>
    {
        TransformMatrix matrix;
        public TriangleComparer(TransformMatrix _matrix)
        {
            matrix = _matrix;
        }
        public int Compare(Triangle triangle1, Triangle triangle2)
        {
            TPoint _p11 = triangle1.p1.ToView(matrix);
            TPoint _p12 = triangle1.p2.ToView(matrix);
            TPoint _p13 = triangle1.p3.ToView(matrix);
            TPoint _p21 = triangle2.p1.ToView(matrix);
            TPoint _p22 = triangle2.p2.ToView(matrix);
            TPoint _p23 = triangle2.p3.ToView(matrix);
            double middle_1 = (_p11.getZ() + _p12.getZ() + _p13.getZ()) / 3;
            double middle_2 = (_p21.getZ() + _p22.getZ() + _p23.getZ()) / 3;
            if (Math.Abs(middle_2 - middle_1) < 1e-4)
                return 0;
            else if (middle_1 > middle_2)
                return -1;
            return 1;
        }
    }
}
