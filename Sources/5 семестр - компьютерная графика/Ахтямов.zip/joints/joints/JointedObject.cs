﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Threading;
using System.Diagnostics;

namespace joints
{
    class JointedObject
    {
        private List<AbstractObject> ObjectsList = new List<AbstractObject>();
        private LightSource light = new LightSource();
        double[] MinXArray;
        double[] MaxXArray;
        double[] MinYArray;
        double[] MaxYArray;
        double[] MinZArray;
        double[] MaxZArray;
        Mutex mutex = new Mutex();
        public void AppendCylinder(Cylinder obj, int round_segments, int height_sements)
        {
            obj.SetLightSource(light);
            obj.Triangulate(round_segments, height_sements);
            ObjectsList.Add(obj);
        }
        public void AddCylinder(Cylinder obj, int round_segments, int height_sements)
        {
            obj.SetLightSource(light);
            obj.Triangulate(round_segments, height_sements);
            ObjectsList.Insert(0, obj);
        }

        public void AppendCone(Cone obj, int round_segments, int height_sements)
        {
            obj.SetLightSource(light);
            obj.Triangulate(round_segments, height_sements);
            ObjectsList.Add(obj);
        }
        public void AddCone(Cone obj, int round_segments, int height_sements)
        {
            obj.SetLightSource(light);
            obj.Triangulate(round_segments, height_sements);
            ObjectsList.Insert(0, obj);
        }
        public void AppendSphere(Sphere obj, int round_segments, int height_segments)
        {
            obj.SetLightSource(light);
            obj.SetJoint(true);
            obj.Triangulate(round_segments, height_segments);
            ObjectsList.Add(obj);
        }
        public void AddSphere(Sphere obj, int round_segments, int height_segments)
        {
            obj.SetLightSource(light);
            obj.Triangulate(round_segments, height_segments);
            obj.SetJoint(true);
            ObjectsList.Insert(0, obj);
        }
        public void RemoveTop()
        {
            if (ObjectsList.Count > 0)
                ObjectsList.RemoveAt(ObjectsList.Count - 1);
        }
        public void RemoveBottom()
        {
            if (ObjectsList.Count > 0)
                ObjectsList.RemoveAt(0);
        }
        public void SetLight(LightSource _light)
        {
            light.SetCoord(_light.GetPosition());
            light.SetIntense(_light.GetIntense());
            foreach (var item in ObjectsList)
                item.SetLightSource(light);
        }
        public void SetLightIntensity(double _intense)
        {
            light.SetIntense(_intense);
            foreach (var item in ObjectsList)
                item.SetLightSource(light);
            Draw();
        }
        public void Draw()
        {
            Stopwatch time = new Stopwatch();
            time.Restart();
            foreach (var item in ObjectsList)
                item.Draw();
            time.Stop();
            GC.Collect();
        }
        public void SetZBuffer(ZBuffer zbuffer)
        {
            foreach (var item in ObjectsList)
                item.SetZBuffer(zbuffer);
        }
        #region Rotations
        public void RotateXUpper(TPoint _center, double angle, int index)
        {
            for (int i = index + 1; i < ObjectsList.Count; i++)
                ObjectsList[i].RotateX(angle, _center);
        }
        public void RotateYUpper(TPoint _center, double angle, int index)
        {
            for (int i = index + 1; i < ObjectsList.Count; i++)
                ObjectsList[i].RotateY(angle, _center);
        }
        public void RotateZUpper(TPoint _center, double angle, int index)
        {
            for (int i = index + 1; i < ObjectsList.Count; i++)
                ObjectsList[i].RotateZ(angle, _center);
        }
        public void RotateXUnder(TPoint _center, double angle, int index)
        {
            for (int i = index-1; i >= 0; i--)
                ObjectsList[i].RotateX(angle, _center);
        }
        public void RotateYUnder(TPoint _center, double angle, int index)
        {
            for (int i = index-1; i >= 0; i--)
                ObjectsList[i].RotateY(angle, _center);
        }
        public void RotateZUnder(TPoint _center, double angle, int index)
        {
            for (int i = index-1; i >= 0; i--)
                ObjectsList[i].RotateZ(angle, _center);
        }
        public void RotateXAll(TPoint _center, double angle, int index)
        {
            for (int i = 0; i < ObjectsList.Count; i++)
                if (i != index)
                    ObjectsList[i].RotateX(angle, _center);
        }
        public void RotateYAll(TPoint _center, double angle, int index)
        {
            for (int i = 0; i < ObjectsList.Count; i++)
                if (i != index)
                    ObjectsList[i].RotateY(angle, _center);
        }
        public void RotateZAll(TPoint _center, double angle, int index)
        {
            for (int i = 0; i < ObjectsList.Count; i++)
                if (i != index)
                    ObjectsList[i].RotateZ(angle, _center);
        }
        #endregion
        #region Camera
        public void RotateCameraX(TPoint center, double angle)
        {
            foreach (var item in ObjectsList)
                item.RotateX(angle, center);
            light.RotateX(angle, center);
        }
        public void RotateCameraY(TPoint center, double angle)
        {
            foreach (var item in ObjectsList)
                item.RotateY(angle, center);
            light.RotateY(angle, center);
        }
        public void Scale(TPoint center, double k)
        {
            foreach (var item in ObjectsList)
                item.Scale(k, center);
            light.Scale(k, center);
        }
        public void MoveCamera(double dx, double dy, double dz)
        {
            foreach (var item in ObjectsList)
                item.Move(dx, dy, dz);
            light.Move(dx, dy, dz);
        }
        #endregion
        public int Size()
        {
            return ObjectsList.Count;
        }
        public void SetColor(Color color, int index)
        {
            ObjectsList[index].SetColor(color);
        }
        public Color GetColor(int index)
        {
            return ObjectsList[index].GetColor();
        }
        public TPoint Middle(int index)
        {
            return ObjectsList[index].GetMiddle();
        }
        public void Clear()
        {
            ObjectsList.Clear();
            light.MatrixRefresh();
        }
        
        private void GetBorders()
        {
            int num = ObjectsList.Count;
            MinXArray = new double[num];
            MaxXArray = new double[num];
            MinYArray = new double[num];
            MaxYArray = new double[num];
            MinZArray = new double[num];
            MaxZArray = new double[num];
            for (int i = 0; i < num; i++)
            {
                MinXArray[i] = ObjectsList[i].MinX();
                MaxXArray[i] = ObjectsList[i].MaxX();
                MinYArray[i] = ObjectsList[i].MinY();
                MaxYArray[i] = ObjectsList[i].MaxY();
                MinZArray[i] = ObjectsList[i].MinZ();
                MaxZArray[i] = ObjectsList[i].MaxZ();
            }
        }
        public bool Collisions()
        {
            GetBorders();
            double eps = 0.5;
            int n = ObjectsList.Count;
            for (int i = 0; i < n - 1; i++)
                for (int j = i + 2; j < n; j++)
                {
                    if (j - i == 1)
                        continue;
                    if (((MinXArray[i] >= MinXArray[j] - eps && MinXArray[i] <= MaxXArray[j] + eps) ||
                        (MaxXArray[i] >= MinXArray[j] - eps && MaxXArray[i] <= MaxXArray[j] + eps)) &&
                        ((MinYArray[i] >= MinYArray[j] - eps && MinYArray[i] <= MaxYArray[j] + eps) ||
                        (MaxYArray[i] >= MinYArray[j] - eps && MaxYArray[i] <= MaxYArray[j] + eps)) &&
                        ((MinZArray[i] >= MinZArray[j] - eps && MinZArray[i] <= MaxZArray[j] + eps) ||
                        (MaxZArray[i] >= MinZArray[j] - eps && MaxZArray[i] <= MaxZArray[j] + eps)))
                        return true;
                }
            return false;
        }
    }
}