﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    public class Vector
    {
        private double x;
        private double y;
        protected double z;
        public double GetX()
        {
            return x;
        }
        public double GetY()
        {
            return y;
        }
        public double GetZ()
        {
            return z;
        }
        public void SetZ(double val)
        {
            z = val;
        }
        public Vector(double _x, double _y, double _z)
        {
            x = _x; y = _y; z = _z;
        }
        public Vector(TPoint begining, TPoint end)
        {
            x = end.getX() - begining.getX();
            y = end.getY() - begining.getY();
            z = end.getZ() - begining.getZ();
        }
        public Vector(Vector vector)
        {
            x = vector.x;
            y = vector.y;
            z = vector.z;
        }
        public double Scalar(Vector vector)
        {
            return (-x) * vector.x + (-y) * vector.y + (-z) * vector.z;
        }
        public double Length()
        {
            return Math.Sqrt(x * x + y * y + z * z);
        }
        public double Cos(Vector vector)
        {
            return (Scalar(vector) / (Length() * vector.Length()));
        }
        public void Negate()
        {
            x = -x; y = -y; z = -z;
        }
        public Vector Cross(Vector vector)
        {
            return new Vector(y * vector.z - z * vector.y, - (x * vector.z - z * vector.x),
                x * vector.y - y * vector.x);
        }
        public Vector Normal(Vector vector)
        {
            Vector result = Cross(vector);
            double length = result.Length();
            result.x = result.x / length;
            result.y = result.y / length;
            result.z = result.z / length;
            return result;
        }
        public void Normalize()
        {
            double length = Length();
            x = x / length;
            y = y / length;
            z = z / length;
        }
        public void Sum(Vector vector)
        {
            x = x + vector.x;
            y = y + vector.y;
            z = z + vector.z;
        }
    }
}
