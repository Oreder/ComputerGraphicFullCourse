﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    public class Quadro
    {
        public TPoint[] points;
        public Quadro(TPoint _p1, TPoint _p2, TPoint _p3, TPoint _p4)
        {
            points = new TPoint[4];
            points[0] = _p1;
            points[1] = _p2;
            points[2] = _p3;
            points[3] = _p4;
        }
    }
}
