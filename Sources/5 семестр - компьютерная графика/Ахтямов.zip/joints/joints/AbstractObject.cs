﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Threading;

namespace joints
{
    class AbstractObject
    {
        protected TransformMatrix transforms = new TransformMatrix();
        protected List<Triangle> container = new List<Triangle>();
        protected ZBuffer zbuffer;
        protected Color color = Color.Red;
        protected LightSource light_source = new LightSource();
        protected TPoint MiddlePoint;
        protected bool Joint = false;
        public bool IsJoint()
        {
            return Joint;
        }
        public void SetJoint(bool _value)
        {
            Joint = _value;
        }
        public void SetTransformMatrix(TransformMatrix _matrix)
        {
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                    transforms.matrix[i,j] = _matrix.matrix[i,j];
        }

        public TPoint GetMiddle()
        {
            return MiddlePoint.ToView(transforms);
        }
        public void RotateX(double angle, TPoint point)
        {
            transforms.Move(-point.getX(), -point.getY(), -point.getZ());
            transforms.RotateX(angle);
            transforms.Move(point.getX(), point.getY(), point.getZ());
        }
        public void RotateY(double angle, TPoint point)
        {
            transforms.Move(-point.getX(), -point.getY(), -point.getZ());
            transforms.RotateY(angle);
            transforms.Move(point.getX(), point.getY(), point.getZ());
        }
        public void RotateZ(double angle, TPoint point)
        {
            transforms.Move(-point.getX(), -point.getY(), -point.getZ());
            transforms.RotateZ(angle);
            transforms.Move(point.getX(), point.getY(), point.getZ());
        }
        public void Move(double dx, double dy, double dz)
        {
            transforms.Move(dx, dy, dz);
        }
        public void Scale(double k, TPoint point)
        {
            transforms.Move(-point.getX(), -point.getY(), -point.getZ());
            transforms.Scale(k, k, k);
            transforms.Move(point.getX(), point.getY(), point.getZ());
        }
        public void SetZBuffer(ZBuffer _buf)
        {
            zbuffer = _buf;
            if (zbuffer != null && container.Count != 0)
                foreach (var elem in container)
                    elem.setZbuffer(zbuffer);
        }
        public void SetColor(Color _color)
        {
            color = _color;
            foreach (var elem in container)
                elem.setColor(color);
        }
        public Color GetColor()
        {
            return color;
        }
        public void SetLightSource(LightSource _src)
        {
            light_source = _src;
        }
        public void Draw()
        {
            TriangleComparer cmp = new TriangleComparer(transforms);
            container.Sort(cmp);
            foreach (var elem in container)
            {
                elem.Draw(transforms, light_source);
            }
        }
        public List<Triangle> GetTriangles()
        {
            return container;
        }
        #region MinMax
        public double MaxX()
        {
            double max = container[0].p1.ToView(transforms).getX();
            foreach (var item in container)
            {
                if (item.p1.ToView(transforms).getX() > max)
                    max = item.p1.ToView(transforms).getX();
                if (item.p2.ToView(transforms).getX() > max)
                    max = item.p2.ToView(transforms).getX();
                if (item.p3.ToView(transforms).getX() > max)
                    max = item.p3.ToView(transforms).getX();
            }
            return max;
        }
        public double MinX()
        {
            double min = container[0].p1.ToView(transforms).getX();
            foreach (var item in container)
            {
                if (item.p1.ToView(transforms).getX() < min)
                    min = item.p1.ToView(transforms).getX();
                if (item.p2.ToView(transforms).getX() < min)
                    min = item.p2.ToView(transforms).getX();
                if (item.p3.ToView(transforms).getX() < min)
                    min = item.p3.ToView(transforms).getX();
            }
            return min;
        }
        public double MaxY()
        {
            double max = container[0].p1.ToView(transforms).getY();
            foreach (var item in container)
            {
                if (item.p1.ToView(transforms).getY() > max)
                    max = item.p1.ToView(transforms).getY();
                if (item.p2.ToView(transforms).getY() > max)
                    max = item.p2.ToView(transforms).getY();
                if (item.p3.ToView(transforms).getY() > max)
                    max = item.p3.ToView(transforms).getY();
            }
            return max;
        }
        public double MinY()
        {
            double min = container[0].p1.ToView(transforms).getY();
            foreach (var item in container)
            {
                if (item.p1.ToView(transforms).getY() < min)
                    min = item.p1.ToView(transforms).getY();
                if (item.p2.ToView(transforms).getY() < min)
                    min = item.p2.ToView(transforms).getY();
                if (item.p3.ToView(transforms).getY() < min)
                    min = item.p3.ToView(transforms).getY();
            }
            return min;
        }
        public double MaxZ()
        {
            double max = container[0].p1.ToView(transforms).getZ();
            foreach (var item in container)
            {
                if (item.p1.ToView(transforms).getZ() > max)
                    max = item.p1.ToView(transforms).getZ();
                if (item.p2.ToView(transforms).getZ() > max)
                    max = item.p2.ToView(transforms).getZ();
                if (item.p3.ToView(transforms).getZ() > max)
                    max = item.p3.ToView(transforms).getZ();
            }
            return max;
        }
        public double MinZ()
        {
            double min = container[0].p1.ToView(transforms).getZ();
            foreach (var item in container)
            {
                if (item.p1.ToView(transforms).getZ() < min)
                    min = item.p1.ToView(transforms).getZ();
                if (item.p2.ToView(transforms).getZ() < min)
                    min = item.p2.ToView(transforms).getZ();
                if (item.p3.ToView(transforms).getZ() < min)
                    min = item.p3.ToView(transforms).getZ();
            }
            return min;
        }
        #endregion
    }
}
