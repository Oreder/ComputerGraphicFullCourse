﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace joints
{
    public class ZBuffer
    {
        private Bitmap_canvas canvas;
        private int[,] z_matrix;
        public ZBuffer(int width, int height)
        {
            canvas = new Bitmap_canvas(width, height);
            initialize();
        }
       
        public void initialize()
        {
	        z_matrix = new int[canvas.getWidth(), canvas.getHeight()];
            int n = canvas.getWidth();
            int m = canvas.getHeight();
	        for (int i = 0; i < n; i++)
		        for (int j = 0; j < m; j++)
			        z_matrix[i,j] = Int32.MaxValue;
        }
        public void refresh()
        {
            int n = canvas.getWidth();
            int m = canvas.getHeight();
            Parallel.For(0, n, i =>
                {
                    for (int j = 0; j < m; j++)
                        z_matrix[i, j] = Int32.MaxValue;
                }
            );
	        canvas.clear();
        }

        #region get_set
        public int get_width()
        {
            return canvas.getWidth();
        }

        public int get_heigth()
        {
            return canvas.getHeight();
        }
        public int getZ(int row, int col)
        {
	        return z_matrix[row, col];
        }

        public Color getColor(int row, int col)
        {
	        return canvas.getColor(row, col);
        }

        public Bitmap GetBitmap()
        {
            return canvas.getBitmap();
        }

        public void setZ(int row, int col, int z)
        {
            if (row <= 0 || col <= 0 || row >= get_width() || col >= get_heigth())
                return;
	        z_matrix[row, col] = z;
        }

        public void setColor(int row, int col, Color color)
        {
	        canvas.DrawPoint(row, col, color);
        }

        public void setColor(TPoint ptr)
        {
            canvas.DrawPoint(ptr.getIntX(), ptr.getIntY(), ptr.getColor());
        }

        /*
        public void DrawTriangle(TPoint p1, TPoint p2, TPoint p3)
        {
            Point [] points = new Point[4];
            points[0] = new Point(p1.getIntX(), p1.getIntY());
            points[1] = new Point(p2.getIntX(), p2.getIntY());
            points[2] = new Point(p3.getIntX(), p3.getIntY());
            points[3] = points[0];
            gr.DrawLines(new Pen(Color.Black), points);
        }*/
#endregion
    }
}
