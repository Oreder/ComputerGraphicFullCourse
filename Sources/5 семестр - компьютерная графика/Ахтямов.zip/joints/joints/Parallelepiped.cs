﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace joints
{
    class Parallelepiped : AbstractObject
    {
        private TPoint bottom;
        private double width, height, length;
        public Parallelepiped(TPoint _bottom, double _length, double _width, double _height)
        {
            bottom = _bottom;
            width = _width;
            height = _height;
            length = _length;
        }
        public Parallelepiped(TPoint _bottom, double _length, double _width, double _height, Color _color)
        {
            bottom = _bottom;
            width = _width;
            height = _height;
            length = _length;
            color = _color;
        }
        public void Triangulate()
        {
            TPoint[] points = new TPoint[8];
            points[0] = new TPoint(bottom.getX() - length / 2, bottom.getY(), bottom.getZ() - width / 2);
            points[1] = new TPoint(bottom.getX() - length / 2, bottom.getY(), bottom.getZ() + width / 2);
            points[2] = new TPoint(bottom.getX() + length / 2, bottom.getY(), bottom.getZ() + width / 2);
            points[3] = new TPoint(bottom.getX() + length / 2, bottom.getY(), bottom.getZ() - width / 2);
            points[4] = new TPoint(bottom.getX() - length / 2, bottom.getY() - height, bottom.getZ() - width / 2);
            points[5] = new TPoint(bottom.getX() - length / 2, bottom.getY() - height, bottom.getZ() + width / 2);
            points[6] = new TPoint(bottom.getX() + length / 2, bottom.getY() - height, bottom.getZ() + width / 2);
            points[7] = new TPoint(bottom.getX() + length / 2, bottom.getY() - height, bottom.getZ() - width / 2);

            // Сохранение в List треугольников
            container.Add(new Triangle(points[0], points[1], points[3]));
            container.Add(new Triangle(points[1], points[2], points[3]));
            container.Add(new Triangle(points[4], points[5], points[7]));
            container.Add(new Triangle(points[6], points[5], points[7]));

            container.Add(new Triangle(points[0], points[4], points[1]));
            container.Add(new Triangle(points[5], points[4], points[1]));
            container.Add(new Triangle(points[1], points[5], points[2]));
            container.Add(new Triangle(points[5], points[6], points[2]));

            container.Add(new Triangle(points[2], points[3], points[6]));
            container.Add(new Triangle(points[3], points[6], points[7]));
            container.Add(new Triangle(points[0], points[4], points[3]));
            container.Add(new Triangle(points[3], points[4], points[7]));

            foreach (var elem in container)
            {
                elem.setColor(color);
                elem.setZbuffer(zbuffer);
            }
        }
    }
}
