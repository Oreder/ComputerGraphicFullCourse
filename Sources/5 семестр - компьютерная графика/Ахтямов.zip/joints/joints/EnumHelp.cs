﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace joints
{
    public class EnumHelp
    {
        public HelpType info;
    }
    public enum HelpType { Modeling, View, Keys, About }
}
