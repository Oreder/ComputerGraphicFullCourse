﻿using SharpDX;
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace SoftEngine
{
    public partial class Device
    {
        private byte[] backBuffer;
        public Bitmap frontBuffer;
        private readonly float[] depthBuffer;
        private readonly int devWidth, devHeight;
        private System.Drawing.Rectangle rectangle;
        private readonly int backBufferLen;

        public Device(int X, int Y)
        {
            devWidth = X;
            devHeight = Y;
            frontBuffer = new Bitmap(devWidth, devHeight);
            backBufferLen = InitBackBuffer();
            depthBuffer = new float[devWidth * devHeight];
        }

        public int InitBackBuffer()
        {
            rectangle = new System.Drawing.Rectangle(new System.Drawing.Point(0, 0), new System.Drawing.Size(devWidth, devHeight));
            var bitmapData = frontBuffer.LockBits(rectangle, System.Drawing.Imaging.ImageLockMode.WriteOnly, frontBuffer.PixelFormat);
            int bytesLen = Math.Abs(bitmapData.Stride) * bitmapData.Height;
            backBuffer = new byte[bytesLen];
            System.Runtime.InteropServices.Marshal.Copy(bitmapData.Scan0, backBuffer, 0, bytesLen);
            frontBuffer.UnlockBits(bitmapData);
            return bytesLen;
        }

        public void Present()
        {
            var bitmapData = frontBuffer.LockBits(rectangle, System.Drawing.Imaging.ImageLockMode.WriteOnly, frontBuffer.PixelFormat);
            System.Runtime.InteropServices.Marshal.Copy(backBuffer, 0, bitmapData.Scan0, backBufferLen);
            frontBuffer.UnlockBits(bitmapData);
        }

        public void Clear()
        {
            for (int index = 0; index < backBufferLen; index += 4)
            {
                backBuffer[index] = 255;
                backBuffer[index + 1] = 255;
                backBuffer[index + 2] = 255;
                backBuffer[index + 3] = 255;
            }
            for (var index = 0; index < depthBuffer.Length; index++)
                depthBuffer[index] = float.MaxValue;
        }

        // Project takes some 3D coordinates and transform them
        // in 2D coordinates using the transformation matrix
        // It also transform the same coordinates and the normal to the vertex 
        // in the 3D world
        public Vertex Project(Vertex vertex, Matrix transMat, Matrix world)
        {
            // transforming the coordinates into 2D space
            var point2d = Vector3.TransformCoordinate(vertex.Coordinates, transMat);
            // transforming the coordinates & the normal to the vertex in the 3D world
            var point3dWorld = Vector3.TransformCoordinate(vertex.Coordinates, world);
            var normal3dWorld = Vector3.TransformCoordinate(vertex.Normal, world);

            // The transformed coordinates will be based on coordinate system
            // starting on the center of the screen. But drawing on screen normally starts
            // from top left. We then need to transform them again to have x:0, y:0 on top left.
            var x = point2d.X * devWidth + devWidth / 2.0f;
            var y = -point2d.Y * devHeight + devHeight / 2.0f;

            return new Vertex
            {
                Coordinates = new Vector3(x, y, point2d.Z),
                Normal = normal3dWorld,
                WorldCoordinates = point3dWorld
            };
        }

        // DrawPoint calls DrawPixel but does the clipping operation before
        public void DrawPoint(Vector3 point, System.Drawing.Color color)
        {
            // Clipping what's visible on screen
            if (point.X >= 0 && point.Y >= 0 && point.X < devWidth && point.Y < devHeight)
            {
                // Drawing a yellow point
                 DrawPixel((int)point.X, (int)point.Y, point.Z, color);            
            }
        }

        public void DrawPoint(Vector2 point)
        {
            // Clipping what's visible on screen
            if (point.X >= 0 && point.Y >= 0 && point.X < devWidth && point.Y < devHeight)
            {
                // Drawing a yellow point
                DrawPixel((int)point.X, (int)point.Y, 0.0f, System.Drawing.Color.FromArgb(255, 0, 0, 0));
            }
        }

        public void DrawPixel(int x, int y, float z, System.Drawing.Color color)
        {
                       int index = (x + y * devWidth);
                       int index4 = index * 4;
                           if (depthBuffer[index] < z)
                          {
                            return;
                           }

                          depthBuffer[index] = z;

                           backBuffer[index4] = color.B;
                           backBuffer[index4 + 1] = color.G;
                           backBuffer[index4 + 2] = color.R;
                           backBuffer[index4 + 3] = color.A;
        }

        public void DrawBline(Vertex point0, Vertex point1, System.Drawing.Color color)
        {
            int x0 = (int)point0.Coordinates.X;
            int y0 = (int)point0.Coordinates.Y;
            int x1 = (int)point1.Coordinates.X;
            int y1 = (int)point1.Coordinates.Y;

            var dx = Math.Abs(x1 - x0);
            var dy = Math.Abs(y1 - y0);
            var sx = (x0 < x1) ? 1 : -1;
            var sy = (y0 < y1) ? 1 : -1;
            var err = dx - dy;
            while (true)
            {
                DrawPoint(new Vector3(x0, y0, 0), color);
                if ((x0 == x1) && (y0 == y1)) break;
                var e2 = 2 * err;
                if (e2 > -dy) { err -= dy; x0 += sx; }
                if (e2 < dx) { err += dx; y0 += sy; }
            }
        }

        // The main method of the engine that re-compute each vertex projection
        // during each frame
        public void Render(Camera camera, Mesh mesh, System.Drawing.Color color, bool shading)
        {
            Clear();
            var viewMatrix = Matrix.LookAtLH(camera.Position, camera.Target, Vector3.UnitY);
            var projectionMatrix = Matrix.PerspectiveFovRH(0.7f,
                                                           (float)devWidth / devHeight,
                                                           0.01f, 1.0f);

                // Beware to apply rotation before translation 
                var worldMatrix = Matrix.RotationYawPitchRoll(mesh.Rotation.Y,
                                                              mesh.Rotation.X, mesh.Rotation.Z) *
                                  Matrix.Translation(mesh.Position);

                var transformMatrix = worldMatrix * viewMatrix * projectionMatrix;

                Parallel.For(0, mesh.Faces.Length, faceIndex =>
                {
                    var face = mesh.Faces[faceIndex];

                    var pixelA = Project(face.A, transformMatrix, worldMatrix);
                    var pixelB = Project(face.B, transformMatrix, worldMatrix);
                    var pixelC = Project(face.C, transformMatrix, worldMatrix);
                    if (shading)
                        DrawTriangle(pixelA, pixelB, pixelC, color);
                     else
                    {
                        DrawBline(pixelA, pixelB, System.Drawing.Color.Black);
                        DrawBline(pixelB, pixelC, System.Drawing.Color.Black);
                        DrawBline(pixelC, pixelA, System.Drawing.Color.Black);
                    }
                   // faceIndex++;
                });
            }
    }
}