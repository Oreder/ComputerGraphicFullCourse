﻿using SharpDX;
using System.Collections.Generic;
using System.IO;

namespace SoftEngine
{
    public class Mesh
    {
        public string Name { get; set; }
        public string FileName { get; set; }
        public Vertex[] Vertices { get; private set; }
        public Face[] Faces { get; set; }
        public Vector3 Position { get; set; }
        public Vector3 Rotation { get; set; }

        public Mesh(string name, string fileName, int verticesCount, int facesCount)
        {
            Vertices = new Vertex[verticesCount];
            Faces = new Face[facesCount];
            Name = name;
            FileName = fileName;
        }
        public void LoadNormalsFromMesh(Face[] morphData)
        {
            for (int i = 0; i < this.Faces.Length; i++)
            {
                this.Faces[i].A.Normal = morphData[i].A.Normal;
                this.Faces[i].B.Normal = morphData[i].B.Normal;
                this.Faces[i].C.Normal = morphData[i].C.Normal;
            }
        }

        public int IsEqual(Mesh mesh)
        {
            int flag = 0;
            if (this.Faces.Length != mesh.Faces.Length)
                return flag = 2;
            if (this.Name == mesh.Name)
                return flag = 1;
            return flag;

        }

        public static void Morph(Mesh mesh, Face[] FaceVertices, int speed)
        {
            for (int i = 0; i < mesh.Faces.Length; i++)
            {
                mesh.Faces[i].A.Coordinates += speed * (FaceVertices[i].A.Coordinates / 1000);
                mesh.Faces[i].B.Coordinates += speed * (FaceVertices[i].B.Coordinates / 1000);
                mesh.Faces[i].C.Coordinates += speed * (FaceVertices[i].C.Coordinates / 1000);
                mesh.Faces[i] = CalcNormals(mesh.Faces[i]);
            }

        }
        public static Face CalcNormals(Face face)
        {
            float x1, y1, z1;
            x1 = face.A.Coordinates.X;
            y1 = face.A.Coordinates.Y;
            z1 = face.A.Coordinates.Z;


            float x2, y2, z2;
            x2 = face.B.Coordinates.X;
            y2 = face.B.Coordinates.Y;
            z2 = face.B.Coordinates.Z;

            float x3, y3, z3;
            x3 = face.C.Coordinates.X;
            y3 = face.C.Coordinates.Y;
            z3 = face.C.Coordinates.Z;

            Vector3 vc1 = face.A.Coordinates - face.B.Coordinates;
            Vector3 vc2 = face.C.Coordinates - face.A.Coordinates;


            Vector3 Normal = Vector3.Cross(vc1, vc2);

            face.A.Normal = Normal;
            face.B.Normal = Normal;
            face.C.Normal = Normal;
            return face;
        }

        public static Face[] CalcMorphData(Mesh mesh1, Mesh mesh2)
        {
            var morphData = new Face[mesh1.Faces.Length];
            for (int i = 0; i < morphData.Length; i++)
            {
                // Vertex Adiff, Bdiff, Cdiff;
                Vector3 ADiff = mesh2.Faces[i].A.Coordinates - mesh1.Faces[i].A.Coordinates;
                Vector3 BDiff = mesh2.Faces[i].B.Coordinates - mesh1.Faces[i].B.Coordinates;
                Vector3 CDiff = mesh2.Faces[i].C.Coordinates - mesh1.Faces[i].C.Coordinates;
                morphData[i].A.Coordinates = ADiff;
                morphData[i].B.Coordinates = BDiff;
                morphData[i].C.Coordinates = CDiff;

                morphData[i].A.Normal = mesh2.Faces[i].A.Normal;
                morphData[i].B.Normal = mesh2.Faces[i].B.Normal;
                morphData[i].C.Normal = mesh2.Faces[i].C.Normal;
            }
            //mesh2.LoadNormalsFromMesh(morphData);
            return morphData;
        }
        public static Mesh CopyMesh(Mesh mesh)
        {
            var meshNew = new Mesh(mesh.Name, mesh.FileName, mesh.Vertices.Length, mesh.Faces.Length);
            for (int i = 0; i < meshNew.Faces.Length; i++)
            {
                meshNew.Faces[i].A.Coordinates = new Vector3 { X = mesh.Faces[i].A.Coordinates.X, Y = mesh.Faces[i].A.Coordinates.Y, Z = mesh.Faces[i].A.Coordinates.Z };
                meshNew.Faces[i].B.Coordinates = new Vector3 { X = mesh.Faces[i].B.Coordinates.X, Y = mesh.Faces[i].B.Coordinates.Y, Z = mesh.Faces[i].B.Coordinates.Z };
                meshNew.Faces[i].C.Coordinates = new Vector3 { X = mesh.Faces[i].C.Coordinates.X, Y = mesh.Faces[i].C.Coordinates.Y, Z = mesh.Faces[i].C.Coordinates.Z };

                meshNew.Faces[i].A.Normal = new Vector3 { X = mesh.Faces[i].A.Normal.X, Y = mesh.Faces[i].A.Normal.Y, Z = mesh.Faces[i].A.Normal.Z };
                meshNew.Faces[i].B.Normal = new Vector3 { X = mesh.Faces[i].B.Normal.X, Y = mesh.Faces[i].B.Normal.Y, Z = mesh.Faces[i].B.Normal.Z };
                meshNew.Faces[i].C.Normal = new Vector3 { X = mesh.Faces[i].C.Normal.X, Y = mesh.Faces[i].C.Normal.Y, Z = mesh.Faces[i].C.Normal.Z };

                meshNew.Faces[i].A.WorldCoordinates = new Vector3 { X = mesh.Faces[i].A.WorldCoordinates.X, Y = mesh.Faces[i].A.WorldCoordinates.Y, Z = mesh.Faces[i].A.WorldCoordinates.Z };
                meshNew.Faces[i].B.WorldCoordinates = new Vector3 { X = mesh.Faces[i].B.WorldCoordinates.X, Y = mesh.Faces[i].B.WorldCoordinates.Y, Z = mesh.Faces[i].B.WorldCoordinates.Z };
                meshNew.Faces[i].C.WorldCoordinates = new Vector3 { X = mesh.Faces[i].C.WorldCoordinates.X, Y = mesh.Faces[i].C.WorldCoordinates.Y, Z = mesh.Faces[i].C.WorldCoordinates.Z };
            }

            for (int i = 0; i < meshNew.Vertices.Length; i++)
            {
                meshNew.Vertices[i].Coordinates = new Vector3 { X = mesh.Vertices[i].Coordinates.X, Y = mesh.Vertices[i].Coordinates.Y, Z = mesh.Vertices[i].Coordinates.Z };
                meshNew.Vertices[i].Normal = new Vector3 { X = mesh.Vertices[i].Normal.X, Y = mesh.Vertices[i].Normal.Y, Z = mesh.Vertices[i].Normal.Z };
                meshNew.Vertices[i].WorldCoordinates = new Vector3 { X = mesh.Vertices[i].WorldCoordinates.X, Y = mesh.Vertices[i].WorldCoordinates.Y, Z = mesh.Vertices[i].WorldCoordinates.Z };
            }

             mesh.Name = mesh.Name;
             mesh.FileName = mesh.FileName;

            meshNew.Position = new Vector3 { X = mesh.Position.X, Y = mesh.Position.Y, Z = mesh.Position.Z };
            meshNew.Rotation = new Vector3 { X = mesh.Rotation.X, Y = mesh.Rotation.Y, Z = mesh.Rotation.Z };
            return meshNew;
        }


        // Loading the JSON file in an asynchronous manner
        public static Mesh LoadJSONFile(string fileName)
        {
            // var mesh = new Mesh();
            var data = File.ReadAllText(fileName);
            // var data = Windows.Storage.FileIO.ReadTextAsync(file);
            dynamic jsonObject = Newtonsoft.Json.JsonConvert.DeserializeObject(data);

            // for (var meshIndex = 0; meshIndex < jsonObject.meshes.Count; meshIndex++)
            //  {
            var verticesArray = jsonObject.meshes[0].vertices;
            // Faces
            var indicesArray = jsonObject.meshes[0].indices;

            var uvCount = jsonObject.meshes[0].uvCount.Value;
            var verticesStep = 1;

            // Depending of the number of texture's coordinates per vertex
            // we're jumping in the vertices array  by 6, 8 & 10 windows frame
            switch ((int)uvCount)
            {
                case 0:
                    verticesStep = 6;
                    break;
                case 1:
                    verticesStep = 8;
                    break;
                case 2:
                    verticesStep = 10;
                    break;
            }

            // the number of interesting vertices information for us
            var verticesCount = verticesArray.Count / verticesStep;
            // number of faces is logically the size of the array divided by 3 (A, B, C)
            var facesCount = indicesArray.Count / 3;
            var mesh = new Mesh(jsonObject.meshes[0].name.Value, Path.GetFileName(fileName), verticesCount, facesCount);
            // Filling the Vertices array of our mesh first
            for (var index = 0; index < verticesCount; index++)
            {
                var x = (float)verticesArray[index * verticesStep].Value;
                var y = (float)verticesArray[index * verticesStep + 1].Value;
                var z = (float)verticesArray[index * verticesStep + 2].Value;
                // Loading the vertex normal exported by Blender
                var nx = (float)verticesArray[index * verticesStep + 3].Value;
                var ny = (float)verticesArray[index * verticesStep + 4].Value;
                var nz = (float)verticesArray[index * verticesStep + 5].Value;
                mesh.Vertices[index] = new Vertex { Coordinates = new Vector3(x, y, z), Normal = new Vector3(nx, ny, nz) };
            }

            // Then filling the Faces array
            for (var index = 0; index < facesCount; index++)
            {
                var a = (int)indicesArray[index * 3].Value;
                var b = (int)indicesArray[index * 3 + 1].Value;
                var c = (int)indicesArray[index * 3 + 2].Value;
                mesh.Faces[index] = new Face { A = mesh.Vertices[a], B = mesh.Vertices[b], C = mesh.Vertices[c] };
                // mesh.Vertices[a].Uses++;
                // mesh.Vertices[b].Uses++;
                // mesh.Vertices[c].Uses++;
            }

            // Getting the position you've set in Blender
            var position = jsonObject.meshes[0].position;
            mesh.Position = new Vector3((float)position[0].Value, (float)position[1].Value, (float)position[2].Value);
            //  meshes.Add(mesh);
            // }
            return mesh;
        }

    }
}
