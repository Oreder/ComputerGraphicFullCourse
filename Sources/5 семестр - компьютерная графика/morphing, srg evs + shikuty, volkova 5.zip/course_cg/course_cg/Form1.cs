﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
//using System.Windows.Forms.M
using System.Windows.Forms;
using System.Timers;
using SharpDX;


namespace SoftEngine
{

    public partial class Form1 : Form
    {
        Device device;
        Mesh mesh;
        Mesh mesh1;
        Mesh mesh2;
        System.Drawing.Color color = System.Drawing.Color.White;
        bool render = false;
        bool morph = false;
        int step = Int32.MaxValue;
        int steps = 1000;
        Face[] morphData;
        Camera cam = new Camera();
        System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
           // device = new Device(pictureBox1.Width, pictureBox1.Height);
            if (!timer1.Enabled)
            {
                timer1.Enabled = true;
                buttonRender.Text = "Pause";
                if (step == Int32.MaxValue)
                    buttonMorph.Enabled = true;
            }
            else
            {
                timer1.Enabled = false;
                buttonRender.Text = "Render";
                buttonMorph.Enabled = false;
            }
            render = true;
        }

        private void UpdateStatusBar()
        {
            labelRenderTime.Text = "Render (ms): " + Convert.ToString(sw.ElapsedMilliseconds) + "\n";
            labelRotationValue.Text = "Rotation (X Y Z): " + trackBarX.Value.ToString() + " " + trackBarY.Value.ToString() + " " + trackBarZ.Value.ToString();
            labelSpeedValue.Text = "Speed: " + (trackBarSpeed.Value).ToString();
            if (step != Int32.MaxValue)
                progressBarMorph.Value = step;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            sw.Restart();
            mesh.Rotation = new Vector3(mesh.Rotation.X + (trackBarX.Value * 0.02f), mesh.Rotation.Y + (trackBarY.Value * 0.02f), mesh.Rotation.Z + (trackBarZ.Value * 0.02f));
            int speed = trackBarSpeed.Value;
            morph = false;
            if (step < steps)
            {
                
                morph = true;
                if (steps - step < speed)
                {
                    speed = steps - step;
                }
                Mesh.Morph(mesh, morphData, speed);
                step += speed;
            }
            if (step == steps)
            {
                if (radioButtonShadingGouraud.Checked == true)
                {
                    mesh.LoadNormalsFromMesh(morphData);
                    labelShading.Text = "Shading: Gouraud";
                }
                step = Int32.MaxValue;
                progressBarMorph.Value = 0;
                buttonMorph.Enabled = true;
                radioButtonShadingGouraud.Enabled = true;
                buttonOpenFile1.Enabled = true;
                buttonOpenFile2.Enabled = true;
            }
            //   }
            if (render)
                if (radioButtonShadingNone.Checked)
                    device.Render(cam, mesh, color, false);
                else
                    device.Render(cam, mesh, color, true);

            device.Present();
            pictureBox1.Image = device.frontBuffer;
            render = morph || Convert.ToBoolean(trackBarX.Value) || Convert.ToBoolean(trackBarY.Value) || Convert.ToBoolean(trackBarZ.Value);
            sw.Stop();
            UpdateStatusBar();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            this.Width -= 248;
            device = new Device(pictureBox1.Width, pictureBox1.Height);
            mesh2 = Mesh.LoadJSONFile("./models/monkey.babylon");
            mesh1 = Mesh.LoadJSONFile("./models/torus.babylon");
            mesh = Mesh.CopyMesh(mesh1);
            cam.Position = new Vector3(0, 0, 10.0f);
            cam.Target = Vector3.Zero;
            labelFile1.Text = "File1: " + mesh1.FileName;
            labelFile2.Text = "File2: " + mesh2.FileName;
            labelSpeedValue.Text = "Speed: " + trackBarSpeed.Value.ToString();

        }

        private void trackBar_Scroll(object sender, EventArgs e)
        {
            labelRotationValue.Text = "Rotation (X Y Z): " + trackBarX.Value.ToString() + " " + trackBarY.Value.ToString() + " " + trackBarZ.Value.ToString();
        }

        private void buttonMorph_Click(object sender, EventArgs e)
        {
            if (mesh1.IsEqual(mesh2) == 1)
            {
                MessageBox.Show("Meshes are equivalent");
                return;
            }
            if (mesh1.IsEqual(mesh2) == 2)
            {
                MessageBox.Show("Number of polygons is different");
                return;
            }

            if (mesh.IsEqual(mesh1) == 1)
            {
                mesh.Name = mesh2.Name;
                mesh.FileName = mesh2.FileName;
                morphData = Mesh.CalcMorphData(mesh1, mesh2);
            }
            else
            {
                mesh.Name = mesh1.Name;
                mesh.FileName = mesh1.FileName;
                morphData = Mesh.CalcMorphData(mesh2, mesh1);
            }
            buttonOpenFile1.Enabled = false;
            buttonOpenFile2.Enabled = false;
            radioButtonShadingGouraud.Enabled = false;
            step = 0;
            if (radioButtonShadingNone.Checked == false)
            labelShading.Text = "Shading: Flat";
            buttonMorph.Enabled = false;
        }

        private void trackBarSteps_Scroll(object sender, EventArgs e)
        {
            labelSpeedValue.Text = "Speed: " + (trackBarSpeed.Value).ToString();
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                color = colorDialog1.Color;
                labelColor.BackColor = colorDialog1.Color;
            }
            render = true;
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            if (buttonShow.Text == ">>")
            {
                this.Width += 248;
                panelSettings.Visible = true;
                buttonShow.Text = "<<";
            }
            else
            {
                panelSettings.Visible = false;
                this.Width -= 248;
                buttonShow.Text = ">>";
            }
        }

        private void buttonOpenFile1_Click(object sender, EventArgs e)
        {
            button1_Click(sender, e);
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                mesh1 = Mesh.LoadJSONFile(openFileDialog1.FileName);
                mesh = Mesh.CopyMesh(mesh1);
                labelFile1.Text = "File1: " + mesh1.FileName;
            }
            render = true;
        }

        private void buttonOpenFile2_Click(object sender, EventArgs e)
        {
            button1_Click(sender, e);
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                mesh2 = Mesh.LoadJSONFile(openFileDialog1.FileName);
                mesh = Mesh.CopyMesh(mesh2);
                labelFile2.Text = "File2: " + mesh2.FileName;
            }
            render = true;
        }


        private void radioButtonShadingNone_CheckedChanged(object sender, EventArgs e)
        {
            buttonColor.Enabled = false;
            labelColor.Enabled = false;
            labelShading.Text = "Shading: None";
            render = true;
        }

        private void radioButtonShadingFlat_CheckedChanged(object sender, EventArgs e)
        {
            labelShading.Text = "Shading: Flat";
            buttonColor.Enabled = true;
            for (int i = 0; i < mesh.Faces.Length; i++)
            {
                mesh.Faces[i] = Mesh.CalcNormals(mesh.Faces[i]);
            }
            render = true;
        }

        private void radioButtonShadingGouraud_CheckedChanged(object sender, EventArgs e)
        {
            labelShading.Text = "Shading: Gouraud";
            buttonColor.Enabled = true;
            if (mesh.IsEqual(mesh1) == 1)
            {
                for (int i = 0; i < mesh.Faces.Length; i++)
                {
                    mesh.Faces[i].A.Normal = mesh1.Faces[i].A.Normal;
                    mesh.Faces[i].B.Normal = mesh1.Faces[i].B.Normal;
                    mesh.Faces[i].C.Normal = mesh1.Faces[i].C.Normal;
                }
            }
            if (mesh.IsEqual(mesh2) == 1)
            {
                for (int i = 0; i < mesh.Faces.Length; i++)
                {
                    mesh.Faces[i].A.Normal = mesh2.Faces[i].A.Normal;
                    mesh.Faces[i].B.Normal = mesh2.Faces[i].B.Normal;
                    mesh.Faces[i].C.Normal = mesh2.Faces[i].C.Normal;
                }
            }
            render = true;
        }
    }
}
