﻿namespace SoftEngine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonRender = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.labelColor = new System.Windows.Forms.Label();
            this.buttonColor = new System.Windows.Forms.Button();
            this.buttonMorph = new System.Windows.Forms.Button();
            this.trackBarSpeed = new System.Windows.Forms.TrackBar();
            this.labelSpeed = new System.Windows.Forms.Label();
            this.labelRotateZ = new System.Windows.Forms.Label();
            this.labelRotateY = new System.Windows.Forms.Label();
            this.trackBarZ = new System.Windows.Forms.TrackBar();
            this.trackBarY = new System.Windows.Forms.TrackBar();
            this.labelRotateX = new System.Windows.Forms.Label();
            this.trackBarX = new System.Windows.Forms.TrackBar();
            this.labelRotation = new System.Windows.Forms.Label();
            this.labelRenderTime = new System.Windows.Forms.Label();
            this.labelRotationValue = new System.Windows.Forms.Label();
            this.labelSpeedValue = new System.Windows.Forms.Label();
            this.labelShading = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.buttonShow = new System.Windows.Forms.Button();
            this.progressBarMorph = new System.Windows.Forms.ProgressBar();
            this.buttonOpenFile1 = new System.Windows.Forms.Button();
            this.buttonOpenFile2 = new System.Windows.Forms.Button();
            this.labelFile1 = new System.Windows.Forms.Label();
            this.labelFile2 = new System.Windows.Forms.Label();
            this.panelSettings = new System.Windows.Forms.Panel();
            this.labelMorph = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.radioButtonShadingGouraud = new System.Windows.Forms.RadioButton();
            this.radioButtonShadingFlat = new System.Windows.Forms.RadioButton();
            this.radioButtonShadingNone = new System.Windows.Forms.RadioButton();
            this.labelShadingValue = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarX)).BeginInit();
            this.panelSettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.MinimumSize = new System.Drawing.Size(640, 480);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 480);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // buttonRender
            // 
            this.buttonRender.AutoSize = true;
            this.buttonRender.Location = new System.Drawing.Point(12, 506);
            this.buttonRender.Name = "buttonRender";
            this.buttonRender.Size = new System.Drawing.Size(61, 23);
            this.buttonRender.TabIndex = 1;
            this.buttonRender.Text = "Render";
            this.buttonRender.UseVisualStyleBackColor = true;
            this.buttonRender.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 22;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // labelColor
            // 
            this.labelColor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelColor.BackColor = System.Drawing.Color.White;
            this.labelColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelColor.Location = new System.Drawing.Point(172, 62);
            this.labelColor.Name = "labelColor";
            this.labelColor.Size = new System.Drawing.Size(14, 14);
            this.labelColor.TabIndex = 14;
            this.labelColor.Text = " ";
            // 
            // buttonColor
            // 
            this.buttonColor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonColor.Location = new System.Drawing.Point(163, 58);
            this.buttonColor.Name = "buttonColor";
            this.buttonColor.Size = new System.Drawing.Size(82, 23);
            this.buttonColor.TabIndex = 13;
            this.buttonColor.Text = "Color";
            this.buttonColor.UseVisualStyleBackColor = true;
            this.buttonColor.Click += new System.EventHandler(this.buttonColor_Click);
            // 
            // buttonMorph
            // 
            this.buttonMorph.AutoSize = true;
            this.buttonMorph.Enabled = false;
            this.buttonMorph.Location = new System.Drawing.Point(394, 506);
            this.buttonMorph.Name = "buttonMorph";
            this.buttonMorph.Size = new System.Drawing.Size(57, 23);
            this.buttonMorph.TabIndex = 12;
            this.buttonMorph.Text = "Morph";
            this.buttonMorph.UseVisualStyleBackColor = true;
            this.buttonMorph.Click += new System.EventHandler(this.buttonMorph_Click);
            // 
            // trackBarSpeed
            // 
            this.trackBarSpeed.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBarSpeed.Location = new System.Drawing.Point(3, 374);
            this.trackBarSpeed.Maximum = 20;
            this.trackBarSpeed.Minimum = 1;
            this.trackBarSpeed.Name = "trackBarSpeed";
            this.trackBarSpeed.Size = new System.Drawing.Size(242, 45);
            this.trackBarSpeed.TabIndex = 11;
            this.trackBarSpeed.Value = 5;
            this.trackBarSpeed.Scroll += new System.EventHandler(this.trackBarSteps_Scroll);
            // 
            // labelSpeed
            // 
            this.labelSpeed.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelSpeed.AutoSize = true;
            this.labelSpeed.Location = new System.Drawing.Point(3, 358);
            this.labelSpeed.Name = "labelSpeed";
            this.labelSpeed.Size = new System.Drawing.Size(41, 13);
            this.labelSpeed.TabIndex = 10;
            this.labelSpeed.Text = "Speed:";
            // 
            // labelRotateZ
            // 
            this.labelRotateZ.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRotateZ.AutoSize = true;
            this.labelRotateZ.Location = new System.Drawing.Point(3, 199);
            this.labelRotateZ.Name = "labelRotateZ";
            this.labelRotateZ.Size = new System.Drawing.Size(17, 13);
            this.labelRotateZ.TabIndex = 9;
            this.labelRotateZ.Text = "Z:";
            // 
            // labelRotateY
            // 
            this.labelRotateY.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRotateY.AutoSize = true;
            this.labelRotateY.Location = new System.Drawing.Point(3, 135);
            this.labelRotateY.Name = "labelRotateY";
            this.labelRotateY.Size = new System.Drawing.Size(17, 13);
            this.labelRotateY.TabIndex = 8;
            this.labelRotateY.Text = "Y:";
            // 
            // trackBarZ
            // 
            this.trackBarZ.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBarZ.Location = new System.Drawing.Point(3, 215);
            this.trackBarZ.Maximum = 3;
            this.trackBarZ.Minimum = -3;
            this.trackBarZ.Name = "trackBarZ";
            this.trackBarZ.Size = new System.Drawing.Size(242, 45);
            this.trackBarZ.TabIndex = 7;
            this.trackBarZ.Scroll += new System.EventHandler(this.trackBar_Scroll);
            // 
            // trackBarY
            // 
            this.trackBarY.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBarY.Location = new System.Drawing.Point(3, 151);
            this.trackBarY.Maximum = 3;
            this.trackBarY.Minimum = -3;
            this.trackBarY.Name = "trackBarY";
            this.trackBarY.Size = new System.Drawing.Size(242, 45);
            this.trackBarY.TabIndex = 6;
            this.trackBarY.Value = -1;
            this.trackBarY.Scroll += new System.EventHandler(this.trackBar_Scroll);
            // 
            // labelRotateX
            // 
            this.labelRotateX.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRotateX.AutoSize = true;
            this.labelRotateX.Location = new System.Drawing.Point(3, 71);
            this.labelRotateX.Name = "labelRotateX";
            this.labelRotateX.Size = new System.Drawing.Size(17, 13);
            this.labelRotateX.TabIndex = 5;
            this.labelRotateX.Text = "X:";
            // 
            // trackBarX
            // 
            this.trackBarX.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBarX.Location = new System.Drawing.Point(3, 87);
            this.trackBarX.Maximum = 3;
            this.trackBarX.Minimum = -3;
            this.trackBarX.Name = "trackBarX";
            this.trackBarX.Size = new System.Drawing.Size(242, 45);
            this.trackBarX.TabIndex = 4;
            this.trackBarX.Value = -1;
            this.trackBarX.Scroll += new System.EventHandler(this.trackBar_Scroll);
            // 
            // labelRotation
            // 
            this.labelRotation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRotation.AutoSize = true;
            this.labelRotation.Location = new System.Drawing.Point(3, 58);
            this.labelRotation.Name = "labelRotation";
            this.labelRotation.Size = new System.Drawing.Size(50, 13);
            this.labelRotation.TabIndex = 3;
            this.labelRotation.Text = "Rotation:";
            // 
            // labelRenderTime
            // 
            this.labelRenderTime.AutoSize = true;
            this.labelRenderTime.Location = new System.Drawing.Point(306, 511);
            this.labelRenderTime.Name = "labelRenderTime";
            this.labelRenderTime.Size = new System.Drawing.Size(82, 13);
            this.labelRenderTime.TabIndex = 11;
            this.labelRenderTime.Text = "Render (ms): 0  ";
            // 
            // labelRotationValue
            // 
            this.labelRotationValue.AutoSize = true;
            this.labelRotationValue.Location = new System.Drawing.Point(178, 511);
            this.labelRotationValue.Name = "labelRotationValue";
            this.labelRotationValue.Size = new System.Drawing.Size(122, 13);
            this.labelRotationValue.TabIndex = 12;
            this.labelRotationValue.Text = "Rotation (X Y Z): 0 0 0   ";
            // 
            // labelSpeedValue
            // 
            this.labelSpeedValue.AutoSize = true;
            this.labelSpeedValue.Location = new System.Drawing.Point(457, 511);
            this.labelSpeedValue.Name = "labelSpeedValue";
            this.labelSpeedValue.Size = new System.Drawing.Size(53, 13);
            this.labelSpeedValue.TabIndex = 13;
            this.labelSpeedValue.Text = "Speed: 1 ";
            // 
            // labelShading
            // 
            this.labelShading.AutoSize = true;
            this.labelShading.Location = new System.Drawing.Point(79, 511);
            this.labelShading.Name = "labelShading";
            this.labelShading.Size = new System.Drawing.Size(93, 13);
            this.labelShading.TabIndex = 15;
            this.labelShading.Text = "Shading: Gouraud";
            // 
            // colorDialog1
            // 
            this.colorDialog1.AllowFullOpen = false;
            this.colorDialog1.AnyColor = true;
            this.colorDialog1.Color = System.Drawing.Color.White;
            // 
            // buttonShow
            // 
            this.buttonShow.Location = new System.Drawing.Point(620, 506);
            this.buttonShow.MaximumSize = new System.Drawing.Size(32, 23);
            this.buttonShow.MinimumSize = new System.Drawing.Size(32, 23);
            this.buttonShow.Name = "buttonShow";
            this.buttonShow.Size = new System.Drawing.Size(32, 23);
            this.buttonShow.TabIndex = 16;
            this.buttonShow.Text = ">>";
            this.buttonShow.UseVisualStyleBackColor = true;
            this.buttonShow.Click += new System.EventHandler(this.buttonShow_Click);
            // 
            // progressBarMorph
            // 
            this.progressBarMorph.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarMorph.Location = new System.Drawing.Point(3, 406);
            this.progressBarMorph.Maximum = 1000;
            this.progressBarMorph.Name = "progressBarMorph";
            this.progressBarMorph.Size = new System.Drawing.Size(242, 13);
            this.progressBarMorph.Step = 1;
            this.progressBarMorph.TabIndex = 14;
            // 
            // buttonOpenFile1
            // 
            this.buttonOpenFile1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpenFile1.Location = new System.Drawing.Point(3, 3);
            this.buttonOpenFile1.Name = "buttonOpenFile1";
            this.buttonOpenFile1.Size = new System.Drawing.Size(24, 23);
            this.buttonOpenFile1.TabIndex = 18;
            this.buttonOpenFile1.Text = "...";
            this.buttonOpenFile1.UseVisualStyleBackColor = true;
            this.buttonOpenFile1.Click += new System.EventHandler(this.buttonOpenFile1_Click);
            // 
            // buttonOpenFile2
            // 
            this.buttonOpenFile2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpenFile2.Location = new System.Drawing.Point(3, 32);
            this.buttonOpenFile2.Name = "buttonOpenFile2";
            this.buttonOpenFile2.Size = new System.Drawing.Size(24, 23);
            this.buttonOpenFile2.TabIndex = 19;
            this.buttonOpenFile2.Text = "...";
            this.buttonOpenFile2.UseVisualStyleBackColor = true;
            this.buttonOpenFile2.Click += new System.EventHandler(this.buttonOpenFile2_Click);
            // 
            // labelFile1
            // 
            this.labelFile1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelFile1.AutoSize = true;
            this.labelFile1.Location = new System.Drawing.Point(33, 8);
            this.labelFile1.Name = "labelFile1";
            this.labelFile1.Size = new System.Drawing.Size(35, 13);
            this.labelFile1.TabIndex = 20;
            this.labelFile1.Text = "File 1:";
            // 
            // labelFile2
            // 
            this.labelFile2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelFile2.AutoSize = true;
            this.labelFile2.Location = new System.Drawing.Point(33, 37);
            this.labelFile2.Name = "labelFile2";
            this.labelFile2.Size = new System.Drawing.Size(35, 13);
            this.labelFile2.TabIndex = 21;
            this.labelFile2.Text = "File 2:";
            // 
            // panelSettings
            // 
            this.panelSettings.Controls.Add(this.labelShadingValue);
            this.panelSettings.Controls.Add(this.radioButtonShadingNone);
            this.panelSettings.Controls.Add(this.radioButtonShadingFlat);
            this.panelSettings.Controls.Add(this.radioButtonShadingGouraud);
            this.panelSettings.Controls.Add(this.progressBarMorph);
            this.panelSettings.Controls.Add(this.labelMorph);
            this.panelSettings.Controls.Add(this.labelColor);
            this.panelSettings.Controls.Add(this.buttonOpenFile1);
            this.panelSettings.Controls.Add(this.buttonOpenFile2);
            this.panelSettings.Controls.Add(this.labelFile2);
            this.panelSettings.Controls.Add(this.trackBarSpeed);
            this.panelSettings.Controls.Add(this.buttonColor);
            this.panelSettings.Controls.Add(this.labelSpeed);
            this.panelSettings.Controls.Add(this.labelFile1);
            this.panelSettings.Controls.Add(this.labelRotation);
            this.panelSettings.Controls.Add(this.labelRotateZ);
            this.panelSettings.Controls.Add(this.trackBarX);
            this.panelSettings.Controls.Add(this.labelRotateX);
            this.panelSettings.Controls.Add(this.labelRotateY);
            this.panelSettings.Controls.Add(this.trackBarY);
            this.panelSettings.Controls.Add(this.trackBarZ);
            this.panelSettings.Location = new System.Drawing.Point(658, 12);
            this.panelSettings.MaximumSize = new System.Drawing.Size(248, 509);
            this.panelSettings.MinimumSize = new System.Drawing.Size(248, 509);
            this.panelSettings.Name = "panelSettings";
            this.panelSettings.Size = new System.Drawing.Size(248, 509);
            this.panelSettings.TabIndex = 22;
            this.panelSettings.Visible = false;
            // 
            // labelMorph
            // 
            this.labelMorph.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelMorph.AutoSize = true;
            this.labelMorph.Location = new System.Drawing.Point(3, 345);
            this.labelMorph.Name = "labelMorph";
            this.labelMorph.Size = new System.Drawing.Size(54, 13);
            this.labelMorph.TabIndex = 22;
            this.labelMorph.Text = "Morphing:";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // radioButtonShadingGouraud
            // 
            this.radioButtonShadingGouraud.AutoSize = true;
            this.radioButtonShadingGouraud.Checked = true;
            this.radioButtonShadingGouraud.Location = new System.Drawing.Point(2, 279);
            this.radioButtonShadingGouraud.Name = "radioButtonShadingGouraud";
            this.radioButtonShadingGouraud.Size = new System.Drawing.Size(66, 17);
            this.radioButtonShadingGouraud.TabIndex = 23;
            this.radioButtonShadingGouraud.TabStop = true;
            this.radioButtonShadingGouraud.Text = "Gouraud";
            this.radioButtonShadingGouraud.UseVisualStyleBackColor = true;
            this.radioButtonShadingGouraud.CheckedChanged += new System.EventHandler(this.radioButtonShadingGouraud_CheckedChanged);
            // 
            // radioButtonShadingFlat
            // 
            this.radioButtonShadingFlat.AutoSize = true;
            this.radioButtonShadingFlat.Location = new System.Drawing.Point(2, 302);
            this.radioButtonShadingFlat.Name = "radioButtonShadingFlat";
            this.radioButtonShadingFlat.Size = new System.Drawing.Size(42, 17);
            this.radioButtonShadingFlat.TabIndex = 24;
            this.radioButtonShadingFlat.Text = "Flat";
            this.radioButtonShadingFlat.UseVisualStyleBackColor = true;
            this.radioButtonShadingFlat.CheckedChanged += new System.EventHandler(this.radioButtonShadingFlat_CheckedChanged);
            // 
            // radioButtonShadingNone
            // 
            this.radioButtonShadingNone.AutoSize = true;
            this.radioButtonShadingNone.Location = new System.Drawing.Point(2, 325);
            this.radioButtonShadingNone.Name = "radioButtonShadingNone";
            this.radioButtonShadingNone.Size = new System.Drawing.Size(51, 17);
            this.radioButtonShadingNone.TabIndex = 25;
            this.radioButtonShadingNone.Text = "None";
            this.radioButtonShadingNone.UseVisualStyleBackColor = true;
            this.radioButtonShadingNone.CheckedChanged += new System.EventHandler(this.radioButtonShadingNone_CheckedChanged);
            // 
            // labelShadingValue
            // 
            this.labelShadingValue.AutoSize = true;
            this.labelShadingValue.Location = new System.Drawing.Point(3, 263);
            this.labelShadingValue.Name = "labelShadingValue";
            this.labelShadingValue.Size = new System.Drawing.Size(49, 13);
            this.labelShadingValue.TabIndex = 26;
            this.labelShadingValue.Text = "Shading:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 541);
            this.Controls.Add(this.panelSettings);
            this.Controls.Add(this.buttonShow);
            this.Controls.Add(this.labelShading);
            this.Controls.Add(this.buttonMorph);
            this.Controls.Add(this.labelSpeedValue);
            this.Controls.Add(this.labelRotationValue);
            this.Controls.Add(this.labelRenderTime);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonRender);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(682, 569);
            this.Name = "Form1";
            this.Text = "Morphing by IU7-51 srg evs";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarX)).EndInit();
            this.panelSettings.ResumeLayout(false);
            this.panelSettings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonRender;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TrackBar trackBarX;
        private System.Windows.Forms.Label labelRotation;
        private System.Windows.Forms.Label labelRotateZ;
        private System.Windows.Forms.Label labelRotateY;
        private System.Windows.Forms.TrackBar trackBarZ;
        private System.Windows.Forms.TrackBar trackBarY;
        private System.Windows.Forms.Label labelRotateX;
        private System.Windows.Forms.Label labelRenderTime;
        private System.Windows.Forms.Label labelRotationValue;
        private System.Windows.Forms.TrackBar trackBarSpeed;
        private System.Windows.Forms.Label labelSpeed;
        private System.Windows.Forms.Label labelSpeedValue;
        private System.Windows.Forms.Button buttonMorph;
        private System.Windows.Forms.Label labelShading;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button buttonColor;
        private System.Windows.Forms.Label labelColor;
        private System.Windows.Forms.Button buttonShow;
        private System.Windows.Forms.ProgressBar progressBarMorph;
        private System.Windows.Forms.Button buttonOpenFile1;
        private System.Windows.Forms.Button buttonOpenFile2;
        private System.Windows.Forms.Label labelFile1;
        private System.Windows.Forms.Label labelFile2;
        private System.Windows.Forms.Panel panelSettings;
        private System.Windows.Forms.Label labelMorph;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.RadioButton radioButtonShadingNone;
        private System.Windows.Forms.RadioButton radioButtonShadingFlat;
        private System.Windows.Forms.RadioButton radioButtonShadingGouraud;
        private System.Windows.Forms.Label labelShadingValue;
    }
}

