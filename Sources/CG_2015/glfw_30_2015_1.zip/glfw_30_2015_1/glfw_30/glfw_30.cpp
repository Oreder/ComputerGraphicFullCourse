// glfw_30.cpp : Defines the entry point for the console application.
//  http://www.glfw.org/docs/latest/quick.html

#include "stdafx.h"

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600

GLdouble A, B, C, D;

static void cursor_callback(GLFWwindow* window, double x, double y)
{
	
}

static void mouse_callback(GLFWwindow* window, int button, int action, int mods)
{
	if(button == GLFW_MOUSE_BUTTON_RIGHT)
	{
		if(action == GLFW_PRESS) glfwSetInputMode( window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
		if(action == GLFW_RELEASE) glfwSetInputMode( window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
	}

	if(button == GLFW_MOUSE_BUTTON_LEFT)
	{
		
	}
}

static void resize_callback(GLFWwindow* window, int width, int height)
{
//	windowWidth = width;
//	windowHeight = height;

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho( 0.0, (GLdouble)width, 0.0, (GLdouble)height, -1, 1);   

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
		
	A = width / 4.0;
	B = 0.0;
	C = D = height / 2.0;

	printf("Reshape occured\n");
}

static void keyboard_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);
}

static void error_callback(int error, const char* description)
{
	fputs(description, stderr);
}

void test_drawing(void)
{
	glPointSize(2.0);
	glBegin(GL_POLYGON);
		glColor3f(0,0,0);
		glVertex2f(50,50);
		glColor3f(1,0,0);
		glVertex2f(50,175);
		glColor3f(0,1,0);
		glVertex2f(175,175);
		glColor3f(0,0,1);
		glVertex2f(175,50);
	glEnd();

	//glPointSize(2.0);
	glLineWidth(3);
	glBegin(GL_LINE_LOOP);
		glColor3f(0,0,0);
		glVertex2f(250,250);
		glColor3f(1,0,0);
		glVertex2f(250,375);
		glColor3f(0,1,0);
		glVertex2f(375,375);
		glColor3f(0,0,1);
		glVertex2f(375,250);
	glEnd();

	glPointSize(10.0);
	glBegin(GL_POINTS);
		glColor3f(0,1,0);
		glVertex2f(350,250);
	glEnd();
}

void drawPoint(int x, int y)
{
	glPointSize(1.0);
	glBegin(GL_POINTS);
		glColor3f(0.1f, 0.4f, 0.4f);
		glVertex2i(x,y);
	glEnd();
}

typedef struct GLintPoint
{
	GLint	x;
	GLint	y;
} GLintPoint;

void serpinsky_drawing(void)
{
	GLintPoint T[3]= {{10,10},{210,310},{410,10}};

	int index = (int)floor((3.0 * rand()) / RAND_MAX);
	// 0, 1 or 2 equally likely
	// 0, 1 ��� 2 �������������
	GLintPoint point = T[index];
	// initial point
	// ��������� �����
	drawPoint(point.x, point.y);
	// draw initial point
	// ������ ��������� �����
	for(int i = 0; i < 100000; i++)
		// draw 1000 dots
		// ������ 1000 �����
	{
		index = (int)floor((3.0 * rand()) / RAND_MAX);
		point.x = (point.x + T[index].x) / 2;
		point.y = (point.y + T[index].y) / 2;
		drawPoint(point.x,point.y);
	}
}

void function_drawing(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
	
	glEnable(GL_LINE_STIPPLE);
	glColor3f(1.0f,0.3f,0.3f);
	//glBegin(GL_LINE_STRIP);
	//glBegin(GL_LINE_LOOP);
	glBegin(GL_POLYGON);
		for(GLdouble x = 0; x < 1.0; x += 0.05)
		{
			GLdouble func = exp(-x) * cos(2 * 3.14159265 * x);
			glVertex2d(A * x + B, C * func + D);
		}
	glEnd();
	glDisable(GL_LINE_STIPPLE);
	//glBegin(GL_LINE_STRIP);
	glBegin(GL_LINE_LOOP);
		for(GLdouble x = 1.0; x < 4.0; x += 0.05)
		{
			GLdouble func = exp(-x) * cos(2 * 3.14159265 * x);
			glVertex2d(A * x + B, C * func + D);
		}
	glEnd();


	glPointSize(4.0);
	glColor3b((GLbyte)20,(GLbyte)26,(GLbyte)250);
	glBegin(GL_POINTS);
		for(GLdouble x = 0; x < 4.0; x += 0.05)
		{
			GLdouble func = exp(-x) * cos(2 * 3.14159265 * x);
			glVertex2d(A * x + B, C * func + D);
		}
	glEnd();
}

void test_drawing_A(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glColor3f(1.0,0.0,0.0);

	glPointSize(10);

	glBegin(GL_POINTS);
		glVertex2i(200,200);
		glVertex2i(300,300);
	glEnd();

	glBegin(GL_QUADS);
	{
		glVertex2i(200, 200);
		glVertex2i(100, 200);
		glVertex2i(100, 100);
		glVertex2i(200, 100);
	}
	glEnd();
}

void draw(void)
{
	test_drawing();
	//test_drawing_A();	
	//serpinsky_drawing();
	//function_drawing();	
}

int main(int argc, _TCHAR* argv[])
{
	// initialise GLFW
    if(!glfwInit())
	{
		printf("glfwInit failed\n");
		return -1;
	}

	glfwSetErrorCallback(error_callback);

	GLFWwindow* window;
	
//	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 1);
//	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);
	//glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE);
	window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Test app", NULL, NULL);
	if (window == NULL)
	{
		printf("glfwOpenWindow failed.\n");
		glfwTerminate();
		return -2;
	}

	int attrib;
	attrib = glfwGetWindowAttrib(window, GLFW_CONTEXT_VERSION_MAJOR);
	attrib = glfwGetWindowAttrib(window, GLFW_CONTEXT_VERSION_MINOR);
	attrib = glfwGetWindowAttrib(window, GLFW_OPENGL_PROFILE);

	glfwMakeContextCurrent(window);

	glfwSetKeyCallback(window, keyboard_callback);
	glfwSetFramebufferSizeCallback(window, resize_callback);
	glfwSetMouseButtonCallback(window, mouse_callback);
	glfwSetCursorPosCallback(window, cursor_callback);
	
    resize_callback(window, SCREEN_WIDTH, SCREEN_HEIGHT);

	while (!glfwWindowShouldClose(window))
	{
		draw();

		glfwSwapBuffers(window);
		
		//glfwPollEvents();
		glfwWaitEvents();
	}

	glfwDestroyWindow(window);

	// clean up and exit
    glfwTerminate();

	return 0;
}
