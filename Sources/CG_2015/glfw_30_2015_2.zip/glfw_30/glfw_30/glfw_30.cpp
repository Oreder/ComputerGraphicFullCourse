// glfw_30.cpp : Defines the entry point for the console application.
// GLFW: http://www.glfw.org/docs/latest/quick.html
// Shaders :http://open.gl/introduction
// GLM: http://glm.g-truc.net/

#include "stdafx.h"

#ifdef SAMPLE_OPENGL_1_1

	#define SCREEN_WIDTH 800
	#define SCREEN_HEIGHT 600

	extern void resize_callback(GLFWwindow* window, int width, int height);
	extern void draw_deprecated(void);

	void init(void)
	{
	}

	void draw(void)
	{
		draw_deprecated();
	}

	void clear(void)
	{
	}

#else

	#define SCREEN_WIDTH 400
	#define SCREEN_HEIGHT 400

	void draw_deprecated()
	{	
		glPointSize(2.0);
		glBegin(GL_POLYGON);
			glColor3f(0,0,0);
			glVertex2f(0.050f,0.050f);
			glColor3f(1,0,0);
			glVertex2f(0.050f,0.175f);
			glColor3f(0,1,0);
			glVertex2f(0.175f,0.175f);
			glColor3f(0,0,1);
			glVertex2f(0.175f,0.050f);
		glEnd();

		//glPointSize(2.0);
		glLineWidth(3);
		glBegin(GL_LINE_LOOP);
			glColor3f(0,0,0);
			glVertex2f(0.250f,0.250f);
			glColor3f(1,0,0);
			glVertex2f(0.250f,0.375f);
			glColor3f(0,1,0);
			glVertex2f(0.375f,0.375f);
			glColor3f(0,0,1);
			glVertex2f(0.375f,0.250f);
		glEnd();

		glPointSize(10.0);
		glBegin(GL_POINTS);
			glColor3f(0,1,0);
			glVertex2f(0.850f,0.850f);
			/*glColor3f(1,0,0);
			glVertex2f(0.800f,0.800f);*/
		glEnd();
	}

	extern void init_shaders(void);
	extern void draw_shaders(void);
	extern void clear_shaders(void);

	void init(void)
	{
		#ifndef DRAW_DEPRECATED
			init_shaders();
		#endif	
	}
	
	void draw(void)
	{
		#ifdef DRAW_DEPRECATED
			draw_deprecated();
		#else
			draw_shaders();	
			//glUseProgram(NULL);
			//draw_deprecated();
		#endif
	}

	void clear(void)
	{
		#ifndef DRAW_DEPRECATED
			clear_shaders();
		#endif	
	}

#endif

static void cursor_callback(GLFWwindow* window, double x, double y)
{
	
}

static void mouse_callback(GLFWwindow* window, int button, int action, int mods)
{
	if(button == GLFW_MOUSE_BUTTON_RIGHT)
	{
		if(action == GLFW_PRESS) glfwSetInputMode( window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
		if(action == GLFW_RELEASE) glfwSetInputMode( window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
	}

	if(button == GLFW_MOUSE_BUTTON_LEFT)
	{
		
	}
}

static void keyboard_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);
}

static void error_callback(int error, const char* description)
{
	fputs(description, stderr);
}

int main(int argc, _TCHAR* argv[])
{
	// initialise GLFW
    if(!glfwInit())
	{
		printf("glfwInit failed\n");
		return -1;
	}

	glfwSetErrorCallback(error_callback);

	GLFWwindow* window;
	
#ifndef SAMPLE_OPENGL_1_1
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 2);	

	#ifdef OPENGL_COMPAT_PROFILE
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE);
	#else
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	#endif

#else
	glfwWindowHint(GLFW_ACCUM_RED_BITS,8);
	glfwWindowHint(GLFW_ACCUM_BLUE_BITS,8);
	glfwWindowHint(GLFW_ACCUM_GREEN_BITS,8);
	glfwWindowHint(GLFW_ACCUM_ALPHA_BITS,8);
#endif

	window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Test app", NULL, NULL);
	if (window == NULL)
	{
		printf("glfwOpenWindow failed. Can your hardware handle OpenGL 3.2?\n");
		glfwTerminate();
		return -2;
	}

	int attrib;
	attrib = glfwGetWindowAttrib(window, GLFW_CONTEXT_VERSION_MAJOR);
	attrib = glfwGetWindowAttrib(window, GLFW_CONTEXT_VERSION_MINOR);
	attrib = glfwGetWindowAttrib(window, GLFW_OPENGL_PROFILE);

	glfwMakeContextCurrent(window);

	glfwSetKeyCallback(window, keyboard_callback);
	glfwSetMouseButtonCallback(window, mouse_callback);
	glfwSetCursorPosCallback(window, cursor_callback);

#ifdef SAMPLE_OPENGL_1_1
	glfwSetFramebufferSizeCallback(window, resize_callback);
	resize_callback(window, SCREEN_WIDTH, SCREEN_HEIGHT);
#else
    glewExperimental = GL_TRUE;
    glewInit();

	if(glewInit() != GLEW_OK)
	{
		printf("Glew failed to init \n");
		
		glfwDestroyWindow(window);
		glfwTerminate();

		return -3;
	}
#endif

	init();
		
    while (!glfwWindowShouldClose(window))
	{
		draw();

		glfwSwapBuffers(window);
		
		#if defined(SAMPLE_2) || defined(SAMPLE_3)
			glfwPollEvents();
		#else
			glfwWaitEvents();
		#endif
	}

	clear();

	glfwDestroyWindow(window);

	// clean up and exit
    glfwTerminate();

	return 0;
}