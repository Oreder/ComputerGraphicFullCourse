#include "stdafx.h"

#ifdef SAMPLE_OPENGL_1_1

GLdouble A, B, C, D;

void resize_callback(GLFWwindow* window, int width, int height)
{
//	windowWidth = width;
//	windowHeight = height;

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho( 0.0, (GLdouble)width, 0.0, (GLdouble)height, -1, 1);   

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
		
	A = width / 4.0;
	B = 0.0;
	C = D = height / 2.0;

	printf("Reshape occured\n");
}

void test_drawing(void)
{
	glPointSize(2.0);
	glBegin(GL_POLYGON);
		glColor3f(0,0,0);
		glVertex2f(50,50);
		glColor3f(1,0,0);
		glVertex2f(50,175);
		glColor3f(0,1,0);
		glVertex2f(175,175);
		glColor3f(0,0,1);
		glVertex2f(175,50);
	glEnd();

	//glPointSize(2.0);
	glLineWidth(3);
	glBegin(GL_LINE_LOOP);
		glColor3f(0,0,0);
		glVertex2f(250,250);
		glColor3f(1,0,0);
		glVertex2f(250,375);
		glColor3f(0,1,0);
		glVertex2f(375,375);
		glColor3f(0,0,1);
		glVertex2f(375,250);
	glEnd();

	glPointSize(10.0);
	glBegin(GL_POINTS);
		glColor3f(0,1,0);
		glVertex2f(350,250);
	glEnd();
}

void drawPoint(int x, int y)
{
	glPointSize(1.0);
	glBegin(GL_POINTS);
		glColor3f(0.1f, 0.4f, 0.4f);
		glVertex2i(x,y);
	glEnd();
}

typedef struct GLintPoint
{
	GLint	x;
	GLint	y;
} GLintPoint;

void serpinsky_drawing(void)
{
	GLintPoint T[3]= {{10,10},{210,310},{410,10}};

	int index = (int)floor((3.0 * rand()) / RAND_MAX);
	// 0, 1 or 2 equally likely
	// 0, 1 ��� 2 �������������
	GLintPoint point = T[index];
	// initial point
	// ��������� �����
	drawPoint(point.x, point.y);
	// draw initial point
	// ������ ��������� �����
	for(int i = 0; i < 100000; i++)
		// draw 1000 dots
		// ������ 1000 �����
	{
		index = (int)floor((3.0 * rand()) / RAND_MAX);
		point.x = (point.x + T[index].x) / 2;
		point.y = (point.y + T[index].y) / 2;
		drawPoint(point.x,point.y);
	}
}

void function_drawing(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
	
	glEnable(GL_LINE_STIPPLE);
	glColor3f(1.0f,0.3f,0.3f);
	//glBegin(GL_LINE_STRIP);
	//glBegin(GL_LINE_LOOP);
	glBegin(GL_POLYGON);
		for(GLdouble x = 0; x < 1.0; x += 0.05)
		{
			GLdouble func = exp(-x) * cos(2 * 3.14159265 * x);
			glVertex2d(A * x + B, C * func + D);
		}
	glEnd();
	glDisable(GL_LINE_STIPPLE);
	//glBegin(GL_LINE_STRIP);
	glBegin(GL_LINE_LOOP);
		for(GLdouble x = 1.0; x < 4.0; x += 0.05)
		{
			GLdouble func = exp(-x) * cos(2 * 3.14159265 * x);
			glVertex2d(A * x + B, C * func + D);
		}
	glEnd();


	glPointSize(4.0);
	glColor3b((GLbyte)20,(GLbyte)26,(GLbyte)250);
	glBegin(GL_POINTS);
		for(GLdouble x = 0; x < 4.0; x += 0.05)
		{
			GLdouble func = exp(-x) * cos(2 * 3.14159265 * x);
			glVertex2d(A * x + B, C * func + D);
		}
	glEnd();
}

void test_drawing_A(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glColor3f(1.0,0.0,0.0);

	glPointSize(10);

	glBegin(GL_POINTS);
		glVertex2i(200,200);
		glVertex2i(300,300);
	glEnd();

	glBegin(GL_QUADS);
	{
		glVertex2i(200, 200);
		glVertex2i(100, 200);
		glVertex2i(100, 100);
		glVertex2i(200, 100);
	}
	glEnd();
}

void test_accum(void)
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ACCUM_BUFFER_BIT );

	glColor3f(1,0,0);
	glBegin(GL_POLYGON);
		glVertex2f(50,50);
		glVertex2f(50,175);
		glVertex2f(175,175);
		glVertex2f(175,50);
	glEnd();

	glAccum(GL_LOAD,1/3);
	glAccum(GL_RETURN,1.0);
}

void draw_deprecated(void)
{
	//test_accum();
	test_drawing();
	//test_drawing_A();	
	//serpinsky_drawing();
	//function_drawing();	
}

#endif
